plugins {
    id("com.android.application") version "8.7.3" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
    // Chaquopy — 파이썬 엔진을 APK 안에 넣는다. Termux가 필요 없어지는 핵심.
    id("com.chaquo.python") version "16.0.0" apply false
}
