# APK 만들기 — Android Studio 없이

GitHub가 대신 빌드해서 APK 파일을 만들어 줍니다.
**내 PC에는 아무것도 설치하지 않습니다.** 웹 브라우저만 있으면 됩니다.

전체 15분쯤 걸리고, 그중 대부분은 기다리는 시간입니다.

---

## 1단계 · GitHub 가입 (계정 있으면 넘어가기)

1. https://github.com 접속
2. **Sign up** → 이메일·비밀번호·아이디 입력
3. 이메일로 온 인증 코드 입력

무료 계정이면 충분합니다.

## 2단계 · 저장소 만들기

1. 로그인 후 오른쪽 위 **+** → **New repository**
2. **Repository name**: `autotrader-app` (아무 이름이나 됩니다)
3. **Public** 선택
   - ⚠️ Private으로 해도 되지만, 무료 계정은 빌드 시간이 월 2,000분으로
     제한됩니다. Public은 무제한입니다.
   - ⚠️ **API 키는 소스에 들어있지 않습니다.** 키는 앱을 켠 뒤 사용자가
     직접 입력하고 폰에만 저장됩니다. Public으로 둬도 키가 노출되지 않습니다.
4. **Create repository** 클릭

## 3단계 · 파일 올리기

1. `AutoTrader.zip` 압축을 풉니다.
2. 방금 만든 저장소 화면에서 **uploading an existing file** 링크 클릭
   (또는 **Add file** → **Upload files**)
3. 압축을 푼 **`AutoTrader` 폴더를 열어서, 그 안의 내용물 전부**를
   브라우저 창으로 끌어다 놓습니다.

> **파일 수**: 42개라 GitHub 웹 업로드 한도(한 번에 100개) 안에 들어갑니다.
> 엔진 파이썬 코드 84개는 `assets/engines/*.zip` 3개로 묶여 있고,
> 앱이 첫 실행 때 알아서 풉니다.

⚠️ **폴더째로 올리면 안 됩니다.** 저장소 최상단에 `settings.gradle.kts`가
바로 보여야 합니다.

```
올바름                          잘못됨
autotrader-app/                autotrader-app/
├── settings.gradle.kts        └── AutoTrader/
├── build.gradle.kts               ├── settings.gradle.kts
├── app/                           └── ...
└── .github/
```

4. 파일이 다 올라오면 아래 **Commit changes** 클릭

> 숨김 폴더인 `.github`가 안 올라가는 경우가 있습니다.
> 3단계가 끝난 뒤 저장소에 `.github` 폴더가 보이는지 확인하세요.
> 없으면 그 폴더만 다시 끌어다 놓으면 됩니다.

## 4단계 · 빌드 시작

1. 저장소 상단 **Actions** 탭 클릭
2. 처음이면 **I understand my workflows, go ahead and enable them** 클릭
3. 왼쪽 목록에서 **Build APK** 클릭
4. 오른쪽 **Run workflow** 버튼 → 다시 **Run workflow**

노란 점이 돌기 시작하면 빌드 중입니다.

## 5단계 · 기다리기

**첫 빌드는 15~25분** 걸립니다. Chaquopy가 파이썬 런타임과 numpy·pandas를
받아서 앱에 넣기 때문입니다. 두 번째부터는 캐시가 있어 더 빠릅니다.

브라우저를 닫아도 됩니다. GitHub 서버에서 계속 돌아갑니다.

## 6단계 · APK 내려받기

1. 초록색 체크(✓)로 바뀌면 그 실행 기록을 클릭
2. 페이지 맨 아래 **Artifacts** 항목의 **autotrader-apk** 클릭
3. zip이 내려받아집니다. 풀면 `app-debug.apk`가 나옵니다.

## 7단계 · 폰에 설치

APK를 폰으로 옮깁니다. 방법은 아무거나 편한 걸로:
- 카카오톡 **나에게 보내기**
- USB 연결 후 복사
- 폰 브라우저로 GitHub에 로그인해 직접 내려받기

파일을 탭하면 설치가 시작됩니다.

**"출처를 알 수 없는 앱"** 경고가 뜨면:
설정 → 해당 앱(카카오톡/파일관리자 등)에 **이 출처 허용**을 켜고 다시 설치

---

## 빌드가 실패했다면

빨간 X로 끝나면 원인을 볼 수 있습니다.

1. 실패한 실행 기록 클릭
2. **build** 클릭
3. 빨간 X가 붙은 단계를 펼치기
4. 빨간 글씨(`error:` / `FAILED`)가 있는 부분을 복사

그 내용을 저에게 그대로 주시면 고쳐 드리겠습니다.
`Artifacts`의 **build-logs**도 같이 받아 두시면 더 정확합니다.

---

## 코드를 고치고 다시 빌드하려면

GitHub 웹에서 바로 고칠 수 있습니다.

1. 저장소에서 고칠 파일 클릭 → 연필 아이콘(✏️)
2. 수정 후 **Commit changes**
3. **자동으로 다시 빌드됩니다** (main 브랜치에 올리면 자동 실행)
4. Actions 탭에서 새 APK 받기

자주 고칠 만한 것:
| 바꿀 것 | 파일 |
|---|---|
| 앱 이름 | `app/src/main/res/values/strings.xml` |
| AdMob 광고 ID | `app/src/main/res/values/strings.xml` |
| 색상 | `app/src/main/res/values/colors.xml` |
| 매매법 설명 | 엔진 zip 안 — 아래 "엔진 코드 고치기" 참고 |

---

## 엔진 코드(파이썬) 고치기

매매법이나 엔진 로직은 `app/src/main/assets/engines/` 안의 zip에 들어 있습니다.
고치려면 PC에서 원본을 수정한 뒤 다시 묶으면 됩니다.

```bash
python tools/pack_engines.py <한투폴더> <키움폴더> <업비트폴더>
```

예:
```bash
python tools/pack_engines.py E:\#\autotrader E:\#\kiwoom_autotrader E:\#\upbit_autotrader
```

바뀐 zip 3개만 GitHub에 다시 올리면 자동으로 새 APK가 만들어집니다.

⚠️ **앱을 업데이트해도 사용자의 보유 종목·거래 기록은 지워지지 않습니다.**
엔진을 새로 풀 때 `state/` 폴더만 따로 빼뒀다가 되돌려 놓습니다.

---

## ⚠️ 배포 전에 반드시

**1. AdMob ID 교체**

`app/src/main/res/values/strings.xml`의 두 값이 지금은 구글 **테스트 ID**입니다.

```xml
<string name="admob_app_id">ca-app-pub-3940256099942544~3347511713</string>
<string name="admob_banner_id">ca-app-pub-3940256099942544/6300978111</string>
```

테스트 ID 그대로면 수익이 0원이고, 반대로 실제 ID로 본인이 광고를 누르면
계정이 정지됩니다.

**2. 서명된 APK**

지금 만드는 건 **디버그 APK**입니다. 본인 테스트에는 문제없지만:
- 서명이 1년 뒤 만료됩니다
- Google Play에 올릴 수 없습니다

스토어에 올리실 단계가 되면 서명 설정을 추가해 드리겠습니다.
(키스토어를 만들어 GitHub Secrets에 넣고 워크플로에서 서명하는 방식입니다)

**3. 법적 준비**

- 시세정보이용계약 (KIS 제휴법인 + 코스콤)
- 유사투자자문업 신고
- 금융 전문 변호사 검토

이건 코드로 해결되는 부분이 아닙니다.

---

## Android Studio로 하고 싶다면

그 방법도 여전히 됩니다. 프로젝트를 열고 **Build → Build APK(s)** 하면
같은 결과가 나옵니다. GitHub 방식이 나은 점은 설치가 필요 없고 PC 사양을
안 타는 것, 나쁜 점은 매번 인터넷에 올려야 하는 것입니다.
