#!/usr/bin/env python3
"""엔진 소스를 assets용 zip으로 다시 묶는다.

엔진 파이썬 코드를 고친 뒤 이걸 돌리면 앱에 반영된다.

    python tools/pack_engines.py ../../autotrader ../../kiwoom_autotrader ../../upbit_autotrader

인자를 안 주면 tools/engines_src/{kis,kiwoom,upbit} 를 찾는다.

⚠️ 파이썬 파일을 폴더째로 assets에 두지 않고 zip으로 묶는 이유:
   파일이 80개가 넘어 GitHub 웹 업로드 한도(100개)에 걸린다.
"""
from __future__ import annotations

import os
import sys
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "app", "src", "main", "assets", "engines")

# 앱에서 실제로 필요한 것만 담는다. 백테스트 스크립트나 캐시 DB까지 넣으면
# APK가 수백 MB로 불어난다.
# ⚠️ 증권사별 API 모듈 폴더 이름이 제각각이다. 하나라도 빠지면 앱에서
#    "No module named 'kiwoom'" 처럼 죽는다(실제로 키움을 빠뜨려 겪었다).
#      한투   : kis
#      키움   : kiwoom, broker
#      업비트 : upbit
INCLUDE = ("config.py", "main.py", "engine", "web",
           "kis", "kiwoom", "broker", "upbit")
SKIP_DIRS = {"__pycache__", "venv", "logs", "state", ".git"}
SKIP_EXT = {".pyc", ".db", ".log", ".png", ".jpg", ".zip"}


def pack(src_dir: str, engine_id: str) -> None:
    out_path = os.path.join(OUT, f"{engine_id}.zip")
    os.makedirs(OUT, exist_ok=True)
    count = 0
    with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as z:
        for item in INCLUDE:
            p = os.path.join(src_dir, item)
            if not os.path.exists(p):
                continue
            if os.path.isfile(p):
                z.write(p, item)
                count += 1
                continue
            for root, dirs, files in os.walk(p):
                dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
                for f in files:
                    if os.path.splitext(f)[1] in SKIP_EXT:
                        continue
                    full = os.path.join(root, f)
                    z.write(full, os.path.relpath(full, src_dir))
                    count += 1
    size = os.path.getsize(out_path) // 1024
    with zipfile.ZipFile(out_path) as z:
        tops = sorted({n.split("/")[0] for n in z.namelist()})
    print(f"  {engine_id}.zip — {count}개 파일, {size}KB")
    print(f"      담긴 항목: {', '.join(tops)}")


# ⚠️ 키움은 '지정단말기'로 등록된 기기에서만 토큰 발급이 된다(오류 8050).
# 등록된 와이파이(고정 IP)에 붙어 있어야 정상 동작한다.
if __name__ == "__main__":
    ids = ["kis", "kiwoom", "upbit"]
    if len(sys.argv) == 1 + len(ids):
        srcs = sys.argv[1:1 + len(ids)]
    else:
        base = os.path.join(HERE, "engines_src")
        srcs = [os.path.join(base, i) for i in ids]
    missing = [s for s in srcs if not os.path.isdir(s)]
    if missing:
        print("폴더를 못 찾았습니다:", *missing, sep="\n  ")
        print("\n사용법: python tools/pack_engines.py <한투경로> <키움경로> <업비트경로>")
        sys.exit(1)
    print("엔진을 다시 묶습니다:")
    for src, eid in zip(srcs, ids):
        pack(src, eid)
    print("\n완료 — 이제 APK를 다시 빌드하면 반영됩니다.")
