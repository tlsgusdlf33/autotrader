plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.chaquo.python")
}

android {
    namespace = "com.shin.autotrader"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.shin.autotrader"
        minSdk = 26
        targetSdk = 35
        // ⚠️ 덮어 설치(업데이트)가 되려면 versionCode 가 이전보다 작으면 안 된다.
        // 깃허브 액션이 빌드 번호를 APP_VERSION_CODE 로 넣어준다. 손으로 빌드할
        // 때는 1 이 된다 — 같은 번호로 덮어 설치하는 것은 안드로이드가 허용한다.
        versionCode = System.getenv("APP_VERSION_CODE")?.toIntOrNull() ?: 1
        versionName = System.getenv("APP_VERSION_NAME") ?: "1.0"

        // ⚠️ Chaquopy는 CPU 종류(ABI)마다 파이썬 런타임을 통째로 넣는다.
        // 하나 늘릴 때마다 APK가 40MB쯤 커지고 빌드 시간도 그만큼 늘어난다.
        // 실제 폰(갤럭시 S25 포함)은 전부 arm64-v8a라 이것만 넣는다.
        // 에뮬레이터로도 테스트하려면 "x86_64"를 추가하면 된다.
        ndk { abiFilters += listOf("arm64-v8a") }
    }

    // 엔진이 쓰는 파이썬 패키지. numpy/pandas는 Chaquopy가 미리 빌드해 둔
    // 휠을 받아 쓴다(직접 빌드는 안드로이드에서 사실상 불가능).
    chaquopy {
        defaultConfig {
            version = "3.11"
            pip {
                // ⚠️ 여기에는 '순수 파이썬' 또는 Chaquopy가 안드로이드용으로
                // 미리 빌드해 둔 패키지만 넣을 수 있다.
                // FastAPI/uvicorn은 넣지 않는다 — FastAPI가 의존하는 pydantic의
                // 알맹이(pydantic-core)가 Rust 확장이라 빌드에 실패한다:
                //   "Failed to install pydantic-core==2.46.4"
                // 대신 표준 라이브러리로 만든 web/microapi.py 를 쓴다.
                install("requests")
                install("python-dotenv")
                install("pyjwt")
                install("numpy")
                install("pandas")
            }
        }
    }

    // ⚠️ 이 앱에서 가장 중요한 설정이다 — 서명 키를 저장소에 함께 둔다.
    //
    // 안드로이드는 '같은 키로 서명된 APK'만 기존 앱 위에 덮어 설치하게 해준다.
    // 그런데 gradle 이 자동으로 만드는 debug.keystore 는 빌드하는 기계마다
    // 새로 생긴다. 깃허브 액션은 매번 새 기계에서 돌기 때문에 빌드할 때마다
    // 서명이 달라졌고, 그래서 새 APK 를 깔려면 반드시 앱을 지워야 했다
    // (INSTALL_FAILED_UPDATE_INCOMPATIBLE).
    //
    // 앱을 지우면 앱 폴더가 통째로 사라진다. 거기에 들어있던 것 —
    //   · 입력해 둔 API 키·계좌번호
    //   · 엔진 거래 기록(engine_state.db) = **어떤 종목을 어떤 매매법으로 샀는지**
    // 가 전부 날아간다. "고치고 다시 깔면 키 입력과 이전에 매수했던 매매법이
    // 반영되지 않는다"는 문제의 원인이 바로 이것이었다.
    //
    // 키를 고정하면 새 APK 를 그냥 덮어 설치할 수 있고, 앱 폴더가 그대로 남아
    // 키도 거래 기록도 이어진다.
    //
    // ⚠️ 이 키는 저장소에 있으니 비밀이 아니다(구글의 기본 debug 키도 마찬가지다).
    // 개인 기기에 직접 설치해 쓰는 앱이라 이렇게 둔다. 플레이스토어에 올릴
    // 계획이 생기면 그때는 이 키를 쓰지 말고 별도 키를 비밀값으로 넣어야 한다.
    signingConfigs {
        create("shared") {
            storeFile = file("autotrader.jks")
            storePassword = "autotrader"
            keyAlias = "autotrader"
            keyPassword = "autotrader"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("shared")
        }
        release {
            // 개인용이라 코드 축소를 끈다. 켜면 빌드만 느려지고 얻는 게 거의 없다.
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("shared")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { viewBinding = true }

    packaging {
        // 여러 라이브러리가 같은 라이선스 파일을 넣어 충돌하는 걸 막는다
        resources.excludes += setOf("META-INF/LICENSE*", "META-INF/NOTICE*")
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    // API 키를 평문이 아니라 암호화해서 저장한다
    implementation("androidx.security:security-crypto:1.1.0-alpha06")
    // 광고
    implementation("com.google.android.gms:play-services-ads:23.6.0")
}
