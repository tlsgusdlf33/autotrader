plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.chaquo.python")
}

android {
    namespace = "com.shin.autotrader"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.shin.autotrader"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"

        // ⚠️ Chaquopy는 CPU 종류(ABI)마다 파이썬 런타임을 통째로 넣는다.
        // 하나 늘릴 때마다 APK가 40MB쯤 커지고 빌드 시간도 그만큼 늘어난다.
        // 실제 폰(갤럭시 S25 포함)은 전부 arm64-v8a라 이것만 넣는다.
        // 에뮬레이터로도 테스트하려면 "x86_64"를 추가하면 된다.
        ndk { abiFilters += listOf("arm64-v8a") }
    }

    // 엔진이 쓰는 파이썬 패키지. numpy/pandas는 Chaquopy가 미리 빌드해 둔
    // 휠을 받아 쓴다(직접 빌드는 안드로이드에서 사실상 불가능).
    chaquopy {
        defaultConfig {
            version = "3.11"
            pip {
                // ⚠️ 여기에는 '순수 파이썬' 또는 Chaquopy가 안드로이드용으로
                // 미리 빌드해 둔 패키지만 넣을 수 있다.
                // FastAPI/uvicorn은 넣지 않는다 — FastAPI가 의존하는 pydantic의
                // 알맹이(pydantic-core)가 Rust 확장이라 빌드에 실패한다:
                //   "Failed to install pydantic-core==2.46.4"
                // 대신 표준 라이브러리로 만든 web/microapi.py 를 쓴다.
                install("requests")
                install("python-dotenv")
                install("pyjwt")
                install("numpy")
                install("pandas")
            }
        }
    }

    buildTypes {
        release {
            // 개인용이라 코드 축소를 끈다. 켜면 빌드만 느려지고 얻는 게 거의 없다.
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { viewBinding = true }

    packaging {
        // 여러 라이브러리가 같은 라이선스 파일을 넣어 충돌하는 걸 막는다
        resources.excludes += setOf("META-INF/LICENSE*", "META-INF/NOTICE*")
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    // API 키를 평문이 아니라 암호화해서 저장한다
    implementation("androidx.security:security-crypto:1.1.0-alpha06")
    // 광고
    implementation("com.google.android.gms:play-services-ads:23.6.0")
}
