package com.shin.autotrader

import java.net.HttpURLConnection
import java.net.URL

/**
 * 엔진이 살아있는지 확인한다.
 *
 * 대시보드가 응답하면 살아있는 것으로 본다. 인증(PIN)을 걸어뒀다면 401이
 * 돌아오는데, 그것도 "서버는 떠 있다"는 뜻이므로 살아있는 것으로 친다.
 * 응답 내용은 보지 않는다 — 여기서 필요한 건 생존 여부뿐이다.
 */
object Health {
    fun isUp(broker: Broker, timeoutMs: Int = 1500): Boolean = try {
        val conn = (URL(broker.url).openConnection() as HttpURLConnection).apply {
            connectTimeout = timeoutMs
            readTimeout = timeoutMs
            requestMethod = "GET"
            instanceFollowRedirects = false
        }
        try {
            conn.responseCode > 0
        } finally {
            conn.disconnect()
        }
    } catch (_: Exception) {
        false
    }
}
