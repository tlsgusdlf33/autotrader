package com.shin.autotrader

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import java.io.File
import kotlin.concurrent.thread

/**
 * 엔진 하나를 담당하는 서비스.
 *
 * ⚠️ 핵심: 각 하위 클래스는 매니페스트에서 android:process 로 **별도 프로세스**에
 * 등록된다. 그래야 파이썬 인터프리터가 엔진마다 하나씩 생긴다.
 *
 * 왜 이렇게까지 하나:
 *   세 프로젝트가 config, engine, web 이라는 똑같은 모듈 이름을 쓴다. 한
 *   프로세스에서 셋을 돌리면 os.chdir(프로세스 공용)과 sys.path 가 뒤엉켜서,
 *   실제로 한투 포트(8787)에 키움 화면이 뜨고 키움 포트는 아예 안 뜨는 일이
 *   벌어졌다. 프로세스를 나누면 이 문제가 원천적으로 사라진다.
 *
 * 대신 프로세스마다 파이썬 런타임이 올라가므로 메모리를 그만큼 더 쓴다.
 * 쓰지 않는 증권사는 켜지 않는 편이 좋다.
 */
abstract class EngineService : Service() {

    abstract val broker: Broker

    private val tag get() = "Engine-${broker.id}"
    private var wakeLock: PowerManager.WakeLock? = null
    /** 이 프로세스가 실제로 읽어들인 .env 의 지문 */
    private var loadedEnvHash: Int = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(notificationId(), buildNotification("준비 중"))

        // ⚠️ 포그라운드 서비스만으로는 부족하다. 화면이 꺼지면 안드로이드가
        // CPU를 재우기 때문에 매매 루프가 멈출 수 있다 — 보유 종목이 있으면
        // 손절 감시가 멈춘다는 뜻이라 그냥 둘 수 없다.
        // PARTIAL_WAKE_LOCK 은 화면·키보드는 꺼두고 CPU만 깨워둔다.
        wakeLock = getSystemService(PowerManager::class.java)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "autotrader:${broker.id}")
            .apply {
                setReferenceCounted(false)
                acquire()
            }
    }

    override fun onDestroy() {
        // 잡아둔 wake lock 은 반드시 놓아준다. 안 놓으면 서비스가 죽은 뒤에도
        // 배터리를 계속 먹는다.
        runCatching { wakeLock?.takeIf { it.isHeld }?.release() }
        wakeLock = null
        super.onDestroy()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // ⚠️ 이 표시는 '프로세스 단위'여야 한다. 예전엔 서비스 인스턴스 필드라서,
        // 안드로이드가 프로세스는 두고 서비스만 다시 만들면 새 인스턴스가
        // engineStarted=false 로 시작해 파이썬 엔진을 하나 더 띄웠다.
        // 그러면 먼저 뜬 엔진이 대시보드 포트를 붙든 채 살아있고, 두 번째가
        // "Address already in use"로 죽는다. 30초를 기다려도 안 풀린 이유다.
        if (!engineStarted) {
            engineStarted = true
            thread(name = "py-${broker.id}", isDaemon = true) { run() }
        } else if (envHash() != loadedEnvHash && loadedEnvHash != 0) {
            // ⚠️ API 키나 계좌번호를 바꿔도 예전에는 아무 일이 없었다.
            // .env 파일만 새로 쓰이고, 이미 돌고 있는 파이썬은 처음 읽은 설정을
            // 그대로 들고 있어서 옛 계좌를 계속 조회했다(실제로 겪었다 —
            // 종목 없는 계좌로 바꿨는데 옛 계좌 종목이 그대로 떴다).
            //
            // 파이썬은 밖에서 설정을 다시 읽게 만들 수 없다. 그래서 이 프로세스를
            // 끝내고 START_STICKY 로 새로 뜨게 한다. 새 프로세스가 새 .env 를 읽는다.
            Log.w(tag, "설정 또는 엔진 코드가 바뀌어 엔진을 다시 시작합니다")
            // ⚠️ stopSelf() 를 부르면 안 된다. 안드로이드가 "정상 종료"로 보고
            // START_STICKY 재시작을 하지 않는다. 프로세스만 끝내면 서비스가
            // 살아있는 것으로 남아 자동으로 새 프로세스에서 되살아난다.
            //
            // 그리고 죽기 전에 대시보드 포트를 반드시 닫아준다. 안 그러면
            // 새 프로세스가 같은 포트를 못 잡고 죽는다
            // ("Address already in use") — 그러면 화면에는 옛 프로세스가
            // 옛 계좌·옛 코드로 계속 응답해서, 바꾼 게 반영이 안 된 것처럼 보인다.
            runCatching { Python.getInstance().getModule("launcher").callAttr("stop_server") }
            android.os.Process.killProcess(android.os.Process.myPid())
        }
        // 안드로이드가 프로세스를 정리하더라도 되살아나게 한다.
        // 포지션을 들고 있는데 엔진이 죽으면 손절 감시가 멈추기 때문이다.
        return START_STICKY
    }

    private fun run() {
        try {
            // 이 프로세스에서만 쓰는 엔진 폴더를 준비한다.
            // (다른 서비스는 자기 폴더만 건드리므로 서로 충돌하지 않는다)
            val root = File(filesDir, "engines")
            // ⚠️ 엔진 소스(zip)가 앱에 안 들어있으면 여기서 명확히 알린다.
            // 예전에는 파일이 없으면 알 수 없는 예외로 죽어서 원인을 못 찾았다.
            val hasAsset = runCatching {
                assets.list("engines")?.contains("${broker.id}.zip") == true
            }.getOrDefault(false)
            if (!hasAsset) {
                notify("엔진 파일이 없습니다 — 빌드에 ${broker.id}.zip 이 빠졌습니다")
                Log.e(tag, "assets/engines/${broker.id}.zip 없음")
                return
            }
            Assets.unpackIfNeeded(this, root, broker.id)
            val dir = File(root, broker.id)

            if (!File(dir, ".env").exists()) {
                notify("설정이 없습니다 — 앱에서 API 키를 넣어주세요")
                Log.e(tag, ".env 가 없습니다: $dir")
                return
            }

            loadedEnvHash = envHash()
            if (!Python.isStarted()) Python.start(AndroidPlatform(this))
            val py = Python.getInstance()
            notify("시작하는 중")

            // ⚠️ 매도·손절실패를 알림으로 띄우기 위한 감시 스레드.
            // 엔진은 파이썬이라 안드로이드 알림을 직접 못 띄운다. 그래서 엔진이
            // DB에 적어둔 사건을 여기서 주기적으로 읽어 알림으로 바꾼다.
            // 손절이 실패했는데 앱을 안 열어보면 모르고 지나가는 게 제일 위험하다.
            thread(name = "events-${broker.id}", isDaemon = true) { pollEvents(py) }

            // 이 호출은 대시보드 서버가 계속 돌기 때문에 돌아오지 않는다.
            val result = py.getModule("launcher")
                .callAttr("start", dir.absolutePath, broker.port)
                .toString()

            Log.w(tag, "엔진 종료됨: $result")
            notify(if (result.startsWith("error")) "오류: ${result.take(60)}" else "중지됨")
        } catch (e: Throwable) {
            Log.e(tag, "엔진 실행 중 오류", e)
            notify("오류: ${e.message?.take(60)}")
        }
    }

    /**
     * 지금 디스크에 있는 설정·코드의 지문.
     *
     * ⚠️ .env(키·계좌) 뿐 아니라 **엔진 코드 번들 번호**도 같이 넣는다.
     * 자동 업데이트로 새 엔진 코드를 받아도, 이미 돌고 있는 파이썬은 예전 코드를
     * 메모리에 들고 있어서 아무 일도 일어나지 않는다. 번들 번호를 지문에 넣으면
     * 아래 onStartCommand 가 '바뀌었다'고 보고 프로세스를 다시 띄우며,
     * 새 프로세스가 새 코드를 푼 채로 시작한다.
     */
    private fun envHash(): Int = runCatching {
        val env = File(File(filesDir, "engines"), "${broker.id}/.env").readText()
        (env + "|bundle=" + Updater.engineBundle(this)).hashCode()
    }.getOrDefault(0)


    /** 엔진이 남긴 사건을 알림으로 띄운다. */
    private fun pollEvents(py: com.chaquo.python.Python) {
        val launcher = py.getModule("launcher")
        while (true) {
            try {
                Thread.sleep(10_000)
                val json = launcher.callAttr("take_events").toString()
                if (json.length <= 2) continue
                val arr = org.json.JSONArray(json)
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    showEvent(
                        o.optString("level", "info"),
                        o.optString("title"),
                        o.optString("body"),
                    )
                }
            } catch (_: InterruptedException) {
                return
            } catch (e: Throwable) {
                Log.w(tag, "알림 처리 실패", e)
            }
        }
    }

    /**
     * 사건 알림.
     *
     * ⚠️ 상태 알림(진행 중)과 다른 ID를 써야 한다. 같은 ID를 쓰면 상태 알림이
     * 덮어써져서, 엔진이 살아있는지 보여주는 표시가 사라진다.
     * 오류는 소리·진동이 나게 해서 놓치지 않도록 한다.
     */
    private fun showEvent(level: String, title: String, body: String) {
        val isError = level == "error"
        val ch = if (isError) CHANNEL_ALERT else CHANNEL_ID
        val n = NotificationCompat.Builder(this, ch)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("${broker.label} · $title")
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setAutoCancel(true)
            .setPriority(if (isError) NotificationCompat.PRIORITY_HIGH
                         else NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(
                PendingIntent.getActivity(
                    this, broker.port,
                    Intent(this, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
                    PendingIntent.FLAG_IMMUTABLE,
                ),
            )
            .build()
        getSystemService(NotificationManager::class.java)
            .notify(eventNotificationId++, n)
    }

    // ── 알림 ────────────────────────────────────────────────
    private fun notificationId() = 100 + broker.port % 100

    private fun createChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val mgr = getSystemService(NotificationManager::class.java)
        mgr.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ID, "엔진 상태",
                // 상시 표시라 소리·진동은 끈다
                NotificationManager.IMPORTANCE_LOW,
            ).apply { setShowBadge(false) },
        )
        // 매도 실패처럼 즉시 알아야 하는 일은 소리·진동이 나야 한다.
        mgr.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ALERT, "매매 알림",
                NotificationManager.IMPORTANCE_HIGH,
            ),
        )
    }

    private fun notify(text: String) {
        getSystemService(NotificationManager::class.java)
            .notify(notificationId(), buildNotification(text))
    }

    private fun buildNotification(text: String): Notification {
        val tap = PendingIntent.getActivity(
            this, broker.port,
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE,
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("${broker.label} · ${broker.port}")
            .setContentText(text)
            .setContentIntent(tap)
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    companion object {
        const val CHANNEL_ID = "engine_status"
        const val CHANNEL_ALERT = "trade_alert"

        /** 사건 알림은 매번 새 ID로 띄운다 (상태 알림을 덮어쓰지 않게) */
        @Volatile
        private var eventNotificationId = 1000

        /** 이 프로세스에서 파이썬 엔진을 이미 띄웠는가 (서비스가 다시 만들어져도 유지) */
        @Volatile
        private var engineStarted = false
    }
}

class KisEngineService : EngineService() {
    override val broker get() = Brokers.KIS
}

class KiwoomEngineService : EngineService() {
    override val broker get() = Brokers.KIWOOM
}

class UpbitEngineService : EngineService() {
    override val broker get() = Brokers.UPBIT
}
