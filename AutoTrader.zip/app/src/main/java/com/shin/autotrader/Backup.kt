package com.shin.autotrader

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.security.SecureRandom
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * 설정과 거래 기록을 앱 폴더 **밖에** 한 벌 더 보관한다.
 *
 * 왜 필요한가:
 *   앱을 지웠다 다시 깔면 안드로이드가 앱 폴더(filesDir)를 통째로 지운다.
 *   거기에는 두 가지가 들어있다 —
 *     · API 키·계좌번호 (EncryptedSharedPreferences)
 *     · 엔진의 거래 기록 engine_state.db — **어떤 종목을 어떤 매매법으로
 *       샀는지**가 여기에만 있다.
 *   그래서 새로 깔면 키를 다시 넣어야 하고, 계좌에 남아있던 종목은
 *   '모르는 종목'이 되어 기본 매매법(#16)으로 다시 주워담긴다.
 *   실제로 겪은 문제가 이것이다.
 *
 * ⚠️ 근본 대책은 '덮어 설치가 되게 하는 것'이다(고정 서명키 — app/autotrader.jks).
 * 덮어 설치가 되면 앱 폴더가 그대로 남아서 이 백업이 필요 없다.
 * 여기 백업은 그래도 앱을 지워버렸을 때를 위한 안전망이다.
 *
 * 저장 위치는 세 곳이다. 앞의 것부터 찾아 쓴다.
 *   1) filesDir/backup       — 덮어 설치(업데이트)에서는 이것만으로 충분하다
 *   2) 외부 미디어 폴더       — 권한이 필요 없고, 기기에 따라 삭제 후에도 남는다
 *   3) 다운로드/AutoTrader   — 사용자가 눈으로 확인하고 옮겨둘 수 있는 곳
 *
 * ⚠️ 파일에는 주문 권한이 있는 API 키가 들어간다. 절대 평문으로 두지 않는다.
 * AES-GCM으로 암호화하고, 열쇠는 '앱에 박아둔 문자열 + 이 기기의 ANDROID_ID'로
 * 만든다. 파일만 빼가도 다른 기기에서는 풀 수 없다.
 */
object Backup {

    private const val TAG = "Backup"
    private const val DIR_NAME = "AutoTrader"
    private const val FILE_NAME = "autotrader-backup.atb"
    private val MAGIC = byteArrayOf('A'.code.toByte(), 'T'.code.toByte(), 'B'.code.toByte(), 'K'.code.toByte())
    private const val FORMAT: Byte = 1
    /** 1 = 이 기기에서만 풀 수 있음, 0 = 기기 정보 없이 만든 백업 */
    private const val MODE_DEVICE: Byte = 1
    private const val MODE_PLAIN_KEY: Byte = 0
    private const val SECRET = "com.shin.autotrader/backup/v1"
    private const val ITERATIONS = 120_000

    /** 백업에 담을 엔진 파일 — 거래 기록만. 시세 캐시는 다시 받으면 되므로 뺀다. */
    private const val STATE_DB = "engine_state.db"

    // ──────────────────────────────────────────────────────────
    // 저장
    // ──────────────────────────────────────────────────────────

    /**
     * 지금 상태를 백업한다. 실패해도 앱 동작에는 영향이 없어야 하므로
     * 예외를 밖으로 내보내지 않는다.
     *
     * @return 한 곳이라도 쓰는 데 성공했는가
     */
    fun save(ctx: Context): Boolean = try {
        val blob = encrypt(ctx, buildArchive(ctx))
        var ok = false
        // 1) 앱 폴더 안 — 덮어 설치에서는 이것만으로 되살릴 수 있다
        ok = writeFile(File(File(ctx.filesDir, "backup"), FILE_NAME), blob) || ok
        // 2) 외부 미디어 폴더 — 권한이 필요 없다
        externalDir(ctx)?.let { ok = writeFile(File(it, FILE_NAME), blob) || ok }
        // 3) 다운로드 폴더 — 사용자가 직접 챙겨둘 수 있는 유일한 위치
        ok = writeToDownloads(ctx, blob) || ok
        if (ok) Log.w(TAG, "백업 저장 완료 (${blob.size} 바이트)")
        ok
    } catch (e: Throwable) {
        Log.w(TAG, "백업 저장 실패", e)
        false
    }

    /** 백업을 배경 스레드에서 저장한다. 화면을 막지 않는다. */
    fun saveAsync(ctx: Context) {
        val app = ctx.applicationContext
        Thread({ save(app) }, "backup-save").apply { isDaemon = true }.start()
    }

    // ──────────────────────────────────────────────────────────
    // 복구
    // ──────────────────────────────────────────────────────────

    /**
     * 키가 하나도 없는 상태(= 새로 깐 직후)라면 백업을 찾아 스스로 되살린다.
     *
     * ⚠️ 키가 들어있는 상태에서는 아무것도 하지 않는다. 쓰던 설정을 백업으로
     * 덮어버리면 사용자가 방금 바꾼 내용이 사라진다.
     *
     * @return 되살렸는가
     */
    fun autoRestoreIfEmpty(ctx: Context): Boolean {
        if (Vault(ctx).hasAnyCredentials()) return false
        val blob = findLocalBackup(ctx) ?: return false
        return runCatching { restore(ctx, blob, overwriteState = false) }
            .onFailure { Log.w(TAG, "자동 복구 실패", it) }
            .getOrDefault(false)
    }

    /** 사용자가 파일 선택기에서 고른 백업으로 되살린다. */
    fun restoreFrom(ctx: Context, uri: Uri): Boolean {
        val blob = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: throw IllegalStateException("백업 파일을 열 수 없습니다")
        // 엔진이 기록 파일을 붙들고 있으면 덮어써도 되돌려진다. 먼저 멈춘다.
        runCatching { EngineHost.stopAll(ctx) }
        return restore(ctx, blob, overwriteState = true)
    }

    private fun restore(ctx: Context, blob: ByteArray, overwriteState: Boolean): Boolean {
        val archive = decrypt(ctx, blob)
        var creds: JSONObject? = null
        val stateFiles = mutableMapOf<String, ByteArray>()

        ZipInputStream(archive.inputStream()).use { zin ->
            while (true) {
                val entry = zin.nextEntry ?: break
                val name = entry.name
                val bytes = zin.readBytes()
                zin.closeEntry()
                when {
                    name == "creds.json" -> creds = JSONObject(String(bytes))
                    name.startsWith("engines/") -> stateFiles[name] = bytes
                }
            }
        }

        val c = creds ?: return false
        restoreCredentials(ctx, c)
        restoreState(ctx, stateFiles, overwriteState)
        Log.w(TAG, "백업에서 복구했습니다 (거래기록 ${stateFiles.size}개)")
        return true
    }

    // ──────────────────────────────────────────────────────────
    // 담기 / 풀기
    // ──────────────────────────────────────────────────────────

    private fun buildArchive(ctx: Context): ByteArray {
        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { zos ->
            zos.putNextEntry(ZipEntry("meta.json"))
            zos.write(
                JSONObject()
                    .put("saved_at", System.currentTimeMillis())
                    .put("version", appVersion(ctx))
                    .toString().toByteArray(),
            )
            zos.closeEntry()

            zos.putNextEntry(ZipEntry("creds.json"))
            zos.write(dumpCredentials(ctx).toString().toByteArray())
            zos.closeEntry()

            // 엔진 거래 기록. state/ 아래 계좌별로 갈려 있어서 재귀로 훑는다.
            // engine_state.db 만 담는다 — 시세 캐시는 몇십 MB씩 되고, 없으면
            // 다시 받으면 그만이다. 매매법 기록은 전부 이 파일 안에 있다.
            val root = File(ctx.filesDir, "engines")
            Brokers.ALL.forEach { broker ->
                val stateDir = File(root, "${broker.id}/state")
                collectStateFiles(stateDir).forEach { f ->
                    val rel = "engines/${broker.id}/state/" +
                        f.toRelativeString(stateDir).replace(File.separatorChar, '/')
                    zos.putNextEntry(ZipEntry(rel))
                    f.inputStream().use { it.copyTo(zos) }
                    zos.closeEntry()
                }
            }
        }
        return out.toByteArray()
    }

    /** engine_state.db 와 그 저널 파일들 (.db-journal / .db-wal / .db-shm) */
    private fun collectStateFiles(dir: File): List<File> {
        if (!dir.isDirectory) return emptyList()
        val found = mutableListOf<File>()
        dir.listFiles()?.forEach { f ->
            when {
                f.isDirectory -> found += collectStateFiles(f)
                f.name.startsWith(STATE_DB) -> found += f
            }
        }
        return found
    }

    private fun dumpCredentials(ctx: Context): JSONObject {
        val vault = Vault(ctx)
        val brokers = JSONArray()
        Brokers.ALL.forEach { broker ->
            val slots = JSONArray()
            for (i in 0 until vault.slotCount(broker)) {
                val c = vault.load(broker, i)
                slots.put(
                    JSONObject()
                        .put("key", c.key)
                        .put("secret", c.secret)
                        .put("account", c.account)
                        .put("label", c.label),
                )
            }
            brokers.put(
                JSONObject()
                    .put("id", broker.id)
                    .put("enabled", vault.load(broker).enabled)
                    .put("active", vault.activeSlot(broker))
                    .put("slots", slots),
            )
        }
        return JSONObject().put("brokers", brokers)
    }

    private fun restoreCredentials(ctx: Context, json: JSONObject) {
        val vault = Vault(ctx)
        val arr = json.optJSONArray("brokers") ?: return
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val broker = Brokers.ALL.firstOrNull { it.id == o.optString("id") } ?: continue
            val slots = o.optJSONArray("slots") ?: continue
            val n = slots.length().coerceIn(1, Vault.MAX_SLOTS)
            vault.setSlotCount(broker, n)
            for (s in 0 until n) {
                val c = slots.getJSONObject(s)
                vault.save(
                    broker,
                    Credentials(
                        enabled = o.optBoolean("enabled", false),
                        key = c.optString("key"),
                        secret = c.optString("secret"),
                        account = c.optString("account"),
                        label = c.optString("label"),
                    ),
                    s,
                )
            }
            vault.setActiveSlot(broker, o.optInt("active", 0))
        }
    }

    /**
     * 거래 기록 파일을 제자리에 되돌린다.
     *
     * ⚠️ overwriteState=false 면 이미 있는 파일은 건드리지 않는다. 자동 복구는
     * '새로 깐 직후'에만 도는데, 혹시라도 엔진이 벌써 새 기록을 쓰기 시작했다면
     * 그쪽이 더 최신이기 때문이다.
     */
    private fun restoreState(ctx: Context, files: Map<String, ByteArray>, overwriteState: Boolean) {
        val base = ctx.filesDir.canonicalFile
        files.forEach { (rel, bytes) ->
            val target = File(ctx.filesDir, rel)
            // 백업 파일 안의 이름이 "../.." 로 시작하면 앱 폴더 밖에 쓸 수 있다.
            if (!target.canonicalPath.startsWith(base.path + File.separator)) {
                Log.w(TAG, "백업 안에 잘못된 경로가 있어 건너뜁니다: $rel")
                return@forEach
            }
            if (!overwriteState && target.exists()) return@forEach
            runCatching {
                target.parentFile?.mkdirs()
                target.writeBytes(bytes)
            }.onFailure { Log.w(TAG, "복구 실패: $rel", it) }
        }
    }

    // ──────────────────────────────────────────────────────────
    // 암호화
    // ──────────────────────────────────────────────────────────

    private fun encrypt(ctx: Context, plain: ByteArray): ByteArray {
        val rnd = SecureRandom()
        val salt = ByteArray(16).also { rnd.nextBytes(it) }
        val iv = ByteArray(12).also { rnd.nextBytes(it) }
        val device = deviceId(ctx)
        val mode = if (device != null) MODE_DEVICE else MODE_PLAIN_KEY
        val cipher = Cipher.getInstance("AES/GCM/NoPadding").apply {
            init(Cipher.ENCRYPT_MODE, deriveKey(salt, device), GCMParameterSpec(128, iv))
        }
        val body = cipher.doFinal(plain)
        return ByteArrayOutputStream().apply {
            write(MAGIC); write(byteArrayOf(FORMAT, mode)); write(salt); write(iv); write(body)
        }.toByteArray()
    }

    private fun decrypt(ctx: Context, blob: ByteArray): ByteArray {
        require(blob.size > 4 + 2 + 16 + 12) { "백업 파일이 너무 짧습니다" }
        require(blob.copyOfRange(0, 4).contentEquals(MAGIC)) { "백업 파일이 아닙니다" }
        require(blob[4] == FORMAT) { "모르는 백업 형식입니다 (${blob[4]})" }
        val mode = blob[5]
        val salt = blob.copyOfRange(6, 22)
        val iv = blob.copyOfRange(22, 34)
        val body = blob.copyOfRange(34, blob.size)

        // 기기에 묶어 만든 백업이 먼저다. 예전 기기에서 가져온 파일처럼
        // 기기 정보 없이 만든 것도 열 수 있게 두 가지를 다 시도한다.
        val candidates = if (mode == MODE_DEVICE) listOf(deviceId(ctx), null) else listOf(null, deviceId(ctx))
        var last: Throwable? = null
        for (device in candidates.distinct()) {
            try {
                return Cipher.getInstance("AES/GCM/NoPadding").apply {
                    init(Cipher.DECRYPT_MODE, deriveKey(salt, device), GCMParameterSpec(128, iv))
                }.doFinal(body)
            } catch (e: Throwable) {
                last = e
            }
        }
        throw IllegalStateException(
            "백업을 풀 수 없습니다 — 다른 기기에서 만든 파일일 수 있습니다", last,
        )
    }

    private fun deriveKey(salt: ByteArray, device: String?): SecretKeySpec {
        val pw = (SECRET + "|" + (device ?: "")).toCharArray()
        val bits = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            .generateSecret(PBEKeySpec(pw, salt, ITERATIONS, 256)).encoded
        return SecretKeySpec(bits, "AES")
    }

    /**
     * 이 기기를 가리키는 값.
     *
     * ANDROID_ID 는 '기기 + 앱 서명키' 조합마다 정해진다. 서명키를 고정해 두었기
     * 때문에(app/autotrader.jks) 앱을 지웠다 다시 깔아도 같은 값이 나온다.
     */
    private fun deviceId(ctx: Context): String? = runCatching {
        Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ANDROID_ID)
            ?.takeIf { it.isNotBlank() }
    }.getOrNull()

    // ──────────────────────────────────────────────────────────
    // 파일 위치
    // ──────────────────────────────────────────────────────────

    @Suppress("DEPRECATION")
    private fun appVersion(ctx: Context): String = runCatching {
        val info = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
        val code =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) info.longVersionCode
            else info.versionCode.toLong()
        "${info.versionName}($code)"
    }.getOrDefault("?")

    private fun externalDir(ctx: Context): File? = runCatching {
        ctx.externalMediaDirs.firstOrNull { it != null }
            ?.let { File(it, DIR_NAME) }
            ?.apply { mkdirs() }
            ?.takeIf { it.isDirectory }
    }.getOrNull()

    private fun writeFile(target: File, blob: ByteArray): Boolean = runCatching {
        target.parentFile?.mkdirs()
        // 쓰는 도중에 프로세스가 죽으면 반쪽짜리 백업이 남는다. 임시 파일에
        // 다 쓴 뒤 자리를 바꾼다.
        val tmp = File(target.parentFile, target.name + ".tmp")
        tmp.writeBytes(blob)
        target.delete()
        if (!tmp.renameTo(target)) {
            tmp.copyTo(target, overwrite = true)
            tmp.delete()
        }
        target.isFile && target.length() == blob.size.toLong()
    }.getOrDefault(false)

    private fun readFile(f: File): ByteArray? =
        runCatching { if (f.isFile && f.length() > 0) f.readBytes() else null }.getOrNull()

    /**
     * 다운로드/AutoTrader 에 한 벌 둔다.
     *
     * ⚠️ 안드로이드 10부터는 앱이 만든 파일이라도 앱을 지우면 소유권이 끊겨서,
     * 다시 깔았을 때 이 파일을 코드로 읽을 수 없다. 그래서 자동 복구는 1·2번
     * 위치로 하고, 이 파일은 사용자가 파일 선택기로 직접 고를 때 쓴다.
     */
    private fun writeToDownloads(ctx: Context, blob: ByteArray): Boolean = runCatching {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            // 예전 안드로이드는 저장소 권한이 있어야 한다. 없으면 조용히 넘어간다.
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), DIR_NAME)
            return@runCatching writeFile(File(dir, FILE_NAME), blob)
        }
        val resolver = ctx.contentResolver
        val collection = MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        val relative = Environment.DIRECTORY_DOWNLOADS + File.separator + DIR_NAME

        val existing = findDownloadUri(ctx)
        val uri = existing ?: resolver.insert(
            collection,
            ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, FILE_NAME)
                put(MediaStore.Downloads.MIME_TYPE, "application/octet-stream")
                put(MediaStore.Downloads.RELATIVE_PATH, relative)
            },
        ) ?: return@runCatching false

        resolver.openOutputStream(uri, "wt")?.use { it.write(blob) } ?: return@runCatching false
        true
    }.getOrElse {
        Log.w(TAG, "다운로드 폴더 백업 실패", it)
        false
    }

    private fun findDownloadUri(ctx: Context): Uri? = runCatching {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return@runCatching null
        val collection = MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        ctx.contentResolver.query(
            collection,
            arrayOf(MediaStore.Downloads._ID),
            "${MediaStore.Downloads.DISPLAY_NAME}=? AND ${MediaStore.Downloads.RELATIVE_PATH} LIKE ?",
            arrayOf(FILE_NAME, "%$DIR_NAME%"),
            null,
        )?.use { cur ->
            if (cur.moveToFirst()) Uri.withAppendedPath(collection, cur.getLong(0).toString()) else null
        }
    }.getOrNull()

    /** 코드로 열 수 있는 백업 중 가장 최근 것 */
    private fun findLocalBackup(ctx: Context): ByteArray? {
        val candidates = mutableListOf<ByteArray>()
        readFile(File(File(ctx.filesDir, "backup"), FILE_NAME))?.let { candidates += it }
        externalDir(ctx)?.let { d -> readFile(File(d, FILE_NAME))?.let { candidates += it } }
        findDownloadUri(ctx)?.let { uri ->
            runCatching { ctx.contentResolver.openInputStream(uri)?.use(InputStream::readBytes) }
                .getOrNull()?.let { candidates += it }
        }
        // 파일마다 담긴 시각을 보고 가장 최근 것을 고른다. 못 푸는 파일은 버린다.
        return candidates
            .mapNotNull { blob -> savedAt(ctx, blob)?.let { it to blob } }
            .maxByOrNull { it.first }
            ?.second
    }

    private fun savedAt(ctx: Context, blob: ByteArray): Long? = runCatching {
        ZipInputStream(decrypt(ctx, blob).inputStream()).use { zin ->
            while (true) {
                val entry = zin.nextEntry ?: break
                if (entry.name == "meta.json") {
                    return@runCatching JSONObject(String(zin.readBytes())).optLong("saved_at", 0L)
                }
                zin.closeEntry()
            }
        }
        0L
    }.getOrNull()
}
