package com.shin.autotrader

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.webkit.WebView
import android.text.InputType
import android.webkit.JsPromptResult
import android.webkit.JsResult
import android.webkit.WebChromeClient
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.MobileAds
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.shin.autotrader.databinding.ActivityMainBinding
import com.shin.autotrader.databinding.DialogStrategiesBinding
import com.shin.autotrader.databinding.ItemBrokerTabBinding
import com.shin.autotrader.databinding.ItemPaneBinding
import com.shin.autotrader.databinding.ItemStrategyBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private lateinit var vault: Vault
    /** 키가 다 들어와서 실제로 엔진이 도는 증권사 */
    private var active: List<Broker> = emptyList()
    private val panes = mutableMapOf<String, ItemPaneBinding>()
    private val tabs = mutableMapOf<String, ItemBrokerTabBinding>()
    private var shown: String? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        vault = Vault(this)

        // ⚠️ 유튜브가 재생 중 화면을 안 끄는 것과 같은 방식이다.
        // 화면이 꺼지면 안드로이드가 프로세스를 정리할 수 있고, 그러면 엔진이
        // 죽어 손절 감시까지 멈춘다. 앱이 앞에 떠 있는 동안은 화면을 유지한다.
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        active = vault.activeBrokers()
        if (active.isEmpty()) {
            startActivity(Intent(this, SetupActivity::class.java))
            finish()
            return
        }

        buildPanes()
        MobileAds.initialize(this) {}
        b.adView.loadAd(AdRequest.Builder().build())

        b.btnSetup.setOnClickListener {
            startActivity(Intent(this, SetupActivity::class.java))
            finish()
        }
        b.btnStrategies.setOnClickListener { showStrategies() }
        b.btnLog.setOnClickListener { showLog() }
        b.btnKey.setOnClickListener { showKeyPicker() }

        // 엔진은 증권사마다 별도 프로세스에서 돈다 (모듈 이름 충돌 방지).
        lifecycleScope.launch {
            withContext(Dispatchers.IO) {
                runCatching { EngineHost.startEnabled(this@MainActivity) }
            }
            waitForEngines()
            keepUpdated()
        }
    }

    /**
     * 자동 업데이트를 확인하고, 받았으면 바로 반영한다.
     *
     * ⚠️ 엔진 코드를 새로 받으면 **엔진을 다시 띄워야** 반영된다. 이미 돌고 있는
     * 파이썬은 예전 코드를 메모리에 들고 있기 때문이다. EngineHost.startEnabled 를
     * 다시 부르면, 서비스가 지문이 바뀐 것을 보고 프로세스를 새로 띄운다
     * (EngineService.envHash 에 엔진 번들 번호가 들어 있다).
     *
     * ⚠️ 거래 기록 백업도 같은 고리에서 30분마다 함께 돈다. 둘을 따로 두면
     * 화면이 꺼질 때 하나만 취소되는 실수를 하기 쉽다.
     */
    private suspend fun keepUpdated() {
        var first = true
        while (true) {
            withContext(Dispatchers.IO) { runCatching { Backup.save(this@MainActivity) } }

            val r = withContext(Dispatchers.IO) {
                runCatching { Updater.checkNow(this@MainActivity, force = first) }.getOrNull()
            }
            first = false
            if (r?.engineUpdated == true) {
                b.statusLine.text = "매매 로직을 새로 받았습니다 — 엔진을 다시 시작합니다"
                withContext(Dispatchers.IO) {
                    runCatching { EngineHost.startEnabled(this@MainActivity) }
                }
                waitForEngines()
            }
            if (r?.apkReady == true) promptInstall(r.latestVersion)
            delay(30 * 60_000)
        }
    }

    /**
     * 받아둔 APK 설치를 권한다.
     *
     * ⚠️ 여기서 탭 한 번이 꼭 필요하다. 안드로이드는 스토어를 거치지 않은 설치를
     * 무인으로 허용하지 않는다(기기 관리자 앱이나 루팅이 아니면 예외 없다).
     * 매매 로직은 이미 자동으로 반영됐으므로, 이건 화면·서비스 쪽 변경용이다.
     */
    private fun promptInstall(version: String) {
        if (isFinishing || isDestroyed) return
        AlertDialog.Builder(this)
            .setTitle("새 버전 $version 준비됨")
            .setMessage(
                "매매 로직은 이미 반영됐습니다.\n" +
                    "화면·알림까지 새로 하려면 설치가 필요합니다.\n\n" +
                    "설정과 거래 기록은 그대로 남습니다.\n" +
                    "('출처를 알 수 없는 앱' 확인 창이 뜨면 허용해주세요)")
            .setPositiveButton("설치") { _, _ ->
                if (!Updater.installPendingApk(this)) toast("설치 화면을 띄우지 못했습니다")
            }
            .setNegativeButton("나중에", null)
            .show()
    }

    override fun onPause() {
        super.onPause()
        // 화면을 떠날 때 한 번 더 남긴다. 안드로이드가 앱을 정리해도
        // 마지막 상태가 백업에 들어가 있게 하기 위해서다.
        Backup.saveAsync(this)
    }

    override fun onDestroy() {
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        super.onDestroy()
    }

    // ---- 증권사 버튼 + 화면 ----
    @SuppressLint("SetJavaScriptEnabled")
    private fun buildPanes() {
        b.brokerTabs.removeAllViews()
        b.panes.removeAllViews()

        // ⚠️ 버튼은 키를 안 넣은 증권사까지 전부 만든다. 아예 안 보이면
        // 사용자는 "이 앱은 업비트를 지원 안 하나?" 하고 헷갈린다. 대신 흐리게
        // 두고, 눌렀을 때 무엇을 해야 하는지 알려준다.
        Brokers.ALL.forEachIndexed { i, broker ->
            val t = ItemBrokerTabBinding.inflate(LayoutInflater.from(this), b.brokerTabs, false)
            (t.root.layoutParams as? LinearLayout.LayoutParams)?.apply {
                width = 0
                weight = 1f
                if (i > 0) marginStart = 6
            }
            t.tabName.text = broker.label
            t.tabPort.text = broker.port.toString()
            val usable = broker in active
            t.root.alpha = if (usable) 1f else 0.4f
            t.root.setOnClickListener {
                if (usable) show(broker) else toast(
                    "${broker.label}은(는) API 키가 입력되지 않았습니다.\n설정에서 키를 넣어주세요."
                )
            }
            b.brokerTabs.addView(t.root)
            tabs[broker.id] = t
        }

        active.forEach { broker ->
            val p = ItemPaneBinding.inflate(LayoutInflater.from(this), b.panes, false)
            p.paneWeb.settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                useWideViewPort = true
                loadWithOverviewMode = true
                cacheMode = android.webkit.WebSettings.LOAD_NO_CACHE
            }
            p.paneWeb.webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    p.paneEmpty.visibility = View.GONE
                }
            }
            // ⚠️ 이게 없으면 화면 안의 alert()/confirm()/prompt()가 통째로 무시된다.
            // "추적에 추가" 버튼이 매매법 번호를 prompt()로 물어보는데, 답이 즉시
            // null 로 돌아와서 버튼을 눌러도 아무 일도 안 일어났다.
            p.paneWeb.webChromeClient = object : WebChromeClient() {
                override fun onJsAlert(
                    view: WebView?, url: String?, message: String?,
                    result: JsResult?,
                ): Boolean {
                    AlertDialog.Builder(this@MainActivity)
                        .setMessage(message ?: "")
                        .setPositiveButton("확인") { _, _ -> result?.confirm() }
                        .setOnCancelListener { result?.cancel() }
                        .show()
                    return true
                }

                override fun onJsConfirm(
                    view: WebView?, url: String?, message: String?,
                    result: JsResult?,
                ): Boolean {
                    AlertDialog.Builder(this@MainActivity)
                        .setMessage(message ?: "")
                        .setPositiveButton("확인") { _, _ -> result?.confirm() }
                        .setNegativeButton("취소") { _, _ -> result?.cancel() }
                        .setOnCancelListener { result?.cancel() }
                        .show()
                    return true
                }

                override fun onJsPrompt(
                    view: WebView?, url: String?, message: String?,
                    defaultValue: String?, result: JsPromptResult?,
                ): Boolean {
                    val input = EditText(this@MainActivity).apply {
                        setText(defaultValue ?: "")
                        inputType = InputType.TYPE_CLASS_NUMBER
                        setSelection(text.length)
                    }
                    AlertDialog.Builder(this@MainActivity)
                        .setMessage(message ?: "")
                        .setView(input)
                        .setPositiveButton("확인") { _, _ ->
                            result?.confirm(input.text.toString())
                        }
                        .setNegativeButton("취소") { _, _ -> result?.cancel() }
                        .setOnCancelListener { result?.cancel() }
                        .show()
                    return true
                }
            }
            // 만들어만 두고 숨긴다. 화면을 바꿔도 다시 불러오지 않아 빠르다.
            p.root.visibility = View.GONE
            b.panes.addView(p.root)
            panes[broker.id] = p
        }

        active.firstOrNull()?.let { show(it) }
    }

    /** 고른 증권사 화면만 보이게 한다. */
    private fun show(broker: Broker) {
        shown = broker.id
        panes.forEach { (id, p) -> p.root.visibility = if (id == broker.id) View.VISIBLE else View.GONE }
        tabs.forEach { (id, t) ->
            t.root.setBackgroundResource(
                if (id == broker.id) R.drawable.bg_pill_on else R.drawable.bg_pill,
            )
        }
    }

    /** 엔진 생존 여부를 버튼의 점 색으로 보여준다. */
    private fun markUp(broker: Broker, up: Boolean) {
        val color = ContextCompat.getColor(this, if (up) R.color.live else R.color.muted)
        tabs[broker.id]?.tabDot?.background?.mutate()?.setTint(color)
    }

    /**
     * 엔진이 뜰 때까지 기다렸다가 대시보드를 붙인다.
     *
     * 파이썬 기동에는 시간이 걸린다(첫 실행은 더 오래). 바로 loadUrl 하면
     * 연결 실패 화면이 뜨고, 사용자는 앱이 고장난 줄 안다.
     */
    /**
     * 엔진이 뜰 때까지 기다렸다가 대시보드를 붙인다.
     *
     * ⚠️ 첫 실행은 정말 오래 걸린다. 프로세스마다 pandas·numpy를 처음 불러오는
     * 데만 수십 초가 걸리고, 증권사 토큰 발급까지 붙으면 몇 분이 될 수 있다.
     * 예전엔 90초 만에 포기해서 "실패"라고 표시했는데, 실제로는 아직 뜨는
     * 중이었다. 그래서 넉넉히 기다리고, 그동안 엔진 로그를 보여줘서 지금 무엇을
     * 하고 있는지 알 수 있게 한다.
     */
    private suspend fun waitForEngines() {
        val started = System.currentTimeMillis()
        val deadline = started + 6 * 60_000
        val pending = active.toMutableList()

        while (pending.isNotEmpty() && System.currentTimeMillis() < deadline) {
            val ready = withContext(Dispatchers.IO) { pending.filter { Health.isUp(it) } }
            ready.forEach { broker ->
                panes[broker.id]?.paneWeb?.loadUrl(broker.url)
                markUp(broker, true)
                pending.remove(broker)
            }

            val sec = (System.currentTimeMillis() - started) / 1000
            b.statusLine.text = if (pending.isEmpty()) "${active.size}개 작동 중"
            else "엔진을 띄우는 중 ${sec}초 (${active.size - pending.size}/${active.size})"

            // 아직 안 뜬 칸에는 그 엔진이 방금 남긴 로그를 보여준다.
            // "엔진을 띄우는 중..."만 떠 있으면 진행 중인지 멈춘 건지 알 수 없다.
            withContext(Dispatchers.IO) {
                pending.map { it to lastLogLine(it) }
            }.forEach { (broker, line) ->
                panes[broker.id]?.paneEmpty?.text =
                    "${broker.label} 준비 중 (${sec}초)\n\n${line ?: "시작하는 중..."}"
            }

            if (pending.isNotEmpty()) delay(3000)
        }

        pending.forEach { broker ->
            val line = withContext(Dispatchers.IO) { lastLogLine(broker) }
            panes[broker.id]?.paneEmpty?.text =
                "${broker.label} 엔진이 뜨지 않았습니다.\n\n${line ?: "로그가 없습니다 — API 키를 확인해주세요."}"
        }
        if (pending.isNotEmpty()) b.statusLine.text = "${pending.size}개 실패 - 설정을 확인하세요"
    }

    /**
     * 엔진이 남긴 로그의 마지막 의미 있는 줄.
     *
     * 엔진은 별도 프로세스에서 돌지만 앱 폴더는 함께 쓰므로 여기서 읽을 수 있다.
     */
    /** 폰에 실제로 풀려 있는 엔진 코드의 버전 표식. 갱신 확인용. */
    private fun engineVersion(broker: Broker): String? = runCatching {
        File(filesDir, "engines/${broker.id}/state/.engine_version")
            .takeIf { it.exists() }?.readText()
    }.getOrNull()

    private fun lastLogLine(broker: Broker): String? = runCatching {
        val f = File(filesDir, "engines/${broker.id}/logs/engine.log")
        if (!f.exists()) return@runCatching null
        // 로그 한 줄 형식: "2026-08-18 22:50:32,468 [ERROR] kis.client: 토큰 발급 실패..."
        // 화면이 좁으니 시각·모듈명은 떼고 사람이 읽을 메시지만 남긴다.
        val raw = f.readLines().asReversed().firstOrNull { it.isNotBlank() } ?: return@runCatching null
        val afterLevel = raw.substringAfter("] ", "")
        val msg = if (afterLevel.contains(": ")) afterLevel.substringAfter(": ") else afterLevel
        msg.ifBlank { raw }.take(300)
    }.getOrNull()

    // ---- 매매법 켜고 끄기 + 백테스트 성적 ----

    /** 매매법 목록의 정렬 기준. 다음에 열 때도 유지된다. */
    private var strategySort = "trades"

    /**
     * 매매법 화면.
     *
     * 목록에 백테스트 성적(거래 횟수·승률·평균수익률)을 함께 보여준다.
     * ⚠️ 기본 정렬은 **거래 많은 순 → 승률 높은 순**이다. 승률만으로 줄세우면
     * 2건 중 2건 맞은 매매법이 100%로 맨 위에 오는데, 그건 우연과 구분되지 않는다.
     *
     * 백테스트가 도는 동안에는 5초마다 다시 읽어서 진행률을 갱신하고, 끝나면
     * 성적이 저절로 채워진다. 엔진이 주기마다 스스로 돌리기 때문에(자동 실행),
     * 사용자가 아무것도 안 해도 며칠에 한 번씩 숫자가 새로 맞춰진다.
     */
    private fun showStrategies() {
        val d = DialogStrategiesBinding.inflate(layoutInflater)
        val dialog = BottomSheetDialog(this).apply { setContentView(d.root) }
        // 화면을 닫으면 폴링을 멈춘다 — 안 그러면 뒤에서 계속 돈다.
        var alive = true
        dialog.setOnDismissListener { alive = false }
        // ⚠️ render() 는 끝에서 스스로를 다시 부르는 고리다. 버튼을 누를 때마다
        // 새 고리가 시작되면 화면 하나에 폴링이 두 겹, 세 겹으로 돈다.
        // 세대 번호를 올려서, 가장 최근에 시작한 고리만 살아남게 한다.
        var generation = 0

        fun push(body: JSONObject, then: () -> Unit) {
            lifecycleScope.launch {
                withContext(Dispatchers.IO) {
                    // 토글은 엔진마다 각자의 DB에 저장되므로 켜둔 전부에 보낸다
                    active.forEach { runCatching { postJson("${it.url}api/strategies", body) } }
                }
                then()
            }
        }

        /**
         * 매매법 목록과 백테스트 결과를 한 번에 읽어 그린다.
         *
         * ⚠️ 백테스트 결과는 증권사(엔진)마다 따로 쌓인다. 지금 보고 있는
         * 증권사 것을 보여준다 — 한투 캐시로 낸 승률을 업비트 화면에 띄우면
         * 엉뚱한 판단을 하게 된다.
         */
        fun render() {
            val myGen = ++generation
            lifecycleScope.launch {
                val broker = Brokers.ALL.firstOrNull { it.id == shown } ?: active.firstOrNull()
                    ?: return@launch
                val (listJson, btJson) = withContext(Dispatchers.IO) {
                    val l = runCatching { getJson("${broker.url}api/strategies") }.getOrNull()
                    val b = runCatching {
                        getJson("${broker.url}api/backtest?sort=$strategySort")
                    }.getOrNull()
                    l to b
                }
                if (!alive || myGen != generation) return@launch
                val arr = listJson?.optJSONArray("strategies") ?: return@launch

                // 백테스트 결과를 매매법 번호로 찾아쓸 수 있게 펼쳐둔다.
                // results 는 서버가 이미 요청한 순서로 정렬해서 준다.
                val scores = mutableMapOf<Int, JSONObject>()
                val order = mutableListOf<Int>()
                btJson?.optJSONArray("results")?.let { rs ->
                    for (i in 0 until rs.length()) {
                        val r = rs.getJSONObject(i)
                        val id = r.getInt("strategy_id")
                        scores[id] = r
                        order += id
                    }
                }
                d.btSummary.text = backtestSummary(btJson, broker)
                d.btnBtSort.text = if (strategySort == "trades") "거래 많은 순" else "승률 높은 순"
                val running = btJson?.optJSONObject("status")?.optBoolean("running") == true
                d.btnBtRunApp.isEnabled = !running
                d.btnBtRunApp.alpha = if (running) 0.4f else 1f

                // 서버가 준 순서대로 줄세운다. 결과에 없는 매매법은 뒤로 보낸다.
                val rows = (0 until arr.length()).map { arr.getJSONObject(it) }
                val ranked = if (order.isEmpty()) rows else rows.sortedBy { row ->
                    val idx = order.indexOf(row.getInt("id"))
                    if (idx < 0) Int.MAX_VALUE else idx
                }

                d.strategyList.removeAllViews()
                ranked.forEach { s ->
                    val row = ItemStrategyBinding.inflate(layoutInflater, d.strategyList, true)
                    val id = s.getInt("id")
                    row.stratNum.text = "#" + id
                    row.stratName.text = s.getString("name")
                    row.stratDesc.text = s.optString("desc")
                    row.stratScore.text = scoreLine(scores[id])
                    row.stratScore.visibility =
                        if (row.stratScore.text.isBlank()) View.GONE else View.VISIBLE
                    row.stratSwitch.setOnCheckedChangeListener(null)
                    row.stratSwitch.isChecked = s.getBoolean("enabled")
                    row.stratSwitch.setOnCheckedChangeListener { _, on ->
                        push(JSONObject().put("strategy_id", id).put("enabled", on)) {}
                    }
                }

                // 도는 동안에는 5초마다, 아니면 60초마다 다시 읽는다.
                // ⚠️ 느긋한 재조회가 꼭 필요하다. 엔진이 주기마다 스스로 백테스트를
                // 돌리므로, 그 결과가 화면을 다시 열지 않아도 반영되어야 한다.
                delay(if (running) 5_000 else 60_000)
                if (alive && myGen == generation) render()
            }
        }

        d.btnAllOn.setOnClickListener {
            push(JSONObject().put("all", true).put("enabled", true)) { render() }
        }
        d.btnAllOff.setOnClickListener {
            push(JSONObject().put("all", true).put("enabled", false)) { render() }
        }
        d.btnOnly51.setOnClickListener {
            push(JSONObject().put("all", true).put("enabled", false)) {
                push(JSONObject().put("strategy_id", 51).put("enabled", true)) { render() }
            }
        }
        d.btnBtSort.setOnClickListener {
            strategySort = if (strategySort == "trades") "win_rate" else "trades"
            render()
        }
        d.btnBtRunApp.setOnClickListener {
            val broker = Brokers.ALL.firstOrNull { it.id == shown } ?: active.firstOrNull()
                ?: return@setOnClickListener
            d.btnBtRunApp.isEnabled = false
            lifecycleScope.launch {
                withContext(Dispatchers.IO) {
                    runCatching {
                        postJson("${broker.url}api/backtest", JSONObject().put("action", "start"))
                    }
                }
                toast("백테스트를 시작했습니다. 몇 분 걸립니다.")
                render()
            }
        }

        render()
        dialog.show()
    }

    /** 매매법 한 줄에 붙는 백테스트 성적. 측정 안 된 것은 빈 문자열. */
    private fun scoreLine(r: JSONObject?): String {
        if (r == null) return ""
        if (r.optInt("measurable", 1) == 0) return "측정 안 함 · 분봉·호가 필요"
        val trades = r.optInt("trades")
        if (trades <= 0) return "신호 없음"
        val wr = if (r.isNull("win_rate")) null else r.optDouble("win_rate")
        val avg = if (r.isNull("avg_return")) null else r.optDouble("avg_return")
        // ⚠️ 표본이 20건 미만이면 승률 뒤에 물음표를 붙인다. 숫자를 그대로
        // 믿고 매매법을 끄거나 켜면 우연을 따라가게 된다.
        val weak = (r.optInt("wins") + r.optInt("losses")) < 20
        val wrText = wr?.let { String.format("승률 %.0f%%%s", it, if (weak) "?" else "") } ?: "승률 —"
        val avgText = avg?.let { String.format("평균 %+.2f%%", it) } ?: ""
        return "${trades}회 · $wrText · $avgText"
    }

    /** 백테스트 요약 한 덩어리 — 언제 돌렸고, 지금 도는 중인지. */
    private fun backtestSummary(bt: JSONObject?, broker: Broker): String {
        if (bt == null) return "${broker.label} 백테스트 결과를 읽지 못했습니다."
        val status = bt.optJSONObject("status")
        if (status?.optBoolean("running") == true) {
            val stage = status.optString("stage")
            val eta = if (status.isNull("eta_sec")) null else status.optInt("eta_sec")
            val etaText = if (eta != null) " · 약 ${eta / 60}분 ${eta % 60}초 남음" else ""
            return "백테스트 진행 중 — $stage$etaText\n거래 ${status.optInt("trades")}건 수집"
        }
        val run = bt.optJSONObject("run")
            ?: return "아직 백테스트를 돌린 적이 없습니다.\n'백테스트 실행'을 누르면 " +
                "쌓아둔 일봉으로 51개 매매법의 승률을 계산합니다."
        val stamp = java.text.SimpleDateFormat("M월 d일 HH:mm", java.util.Locale.KOREA)
            .format(java.util.Date((run.optDouble("ts") * 1000).toLong()))
        val auto = if (bt.optBoolean("auto", true))
            "자동 실행 켜짐 (${bt.optDouble("interval_h", 24.0).toInt()}시간마다)"
        else "자동 실행 꺼짐"
        val cancelled =
            if (run.optString("status") == "cancelled") " · 중단된 결과(표본 일부)" else ""
        return "$stamp 기준 · 종목 ${run.optInt("stocks")}개 · 최근 ${run.optInt("eval_bars")}일" +
            " · 왕복 ${run.optDouble("fee_pct")}%$cancelled\n" +
            "$auto · 결과는 매수 우선순위에 자동 반영됩니다."
    }

    /**
     * 지금 보고 있는 증권사의 엔진 로그를 띄운다.
     *
     * ⚠️ 이 버튼이 없어서 그동안 문제가 생겨도 원인을 알 수 없었다. 엔진은
     * 초록불이 켜진 채로도 속이 비어 있을 수 있다(설정이 틀리면 조회가 전부
     * 빈 값으로 돌아온다). 그럴 때 여기서 진짜 이유를 볼 수 있다.
     */
    private fun showLog() {
        val broker = Brokers.ALL.firstOrNull { it.id == shown } ?: active.firstOrNull() ?: return
        lifecycleScope.launch {
            val text = withContext(Dispatchers.IO) {
                val f = File(filesDir, "engines/${broker.id}/logs/engine.log")
                if (!f.exists()) "로그 파일이 아직 없습니다.\n엔진이 시작되지 않았을 수 있습니다."
                // 최근 것부터 보이게 뒤집는다. 화면이 좁아 200줄이면 충분하다.
                else f.readLines().takeLast(200).asReversed().joinToString("\n")
                    .ifBlank { "로그가 비어 있습니다." }
            }
            AlertDialog.Builder(this@MainActivity)
                .setTitle("${broker.label} 로그  ·  엔진 ${engineVersion(broker) ?: "?"}")
                .setMessage(text)
                .setPositiveButton("닫기", null)
                .setNeutralButton("복사") { _, _ ->
                    val cb = getSystemService(ClipboardManager::class.java)
                    cb.setPrimaryClip(ClipData.newPlainText("engine log", text))
                    toast("로그를 복사했습니다")
                }
                .show()
        }
    }

    /**
     * 지금 보고 있는 증권사의 키 묶음을 바꾼다.
     *
     * ⚠️ 업비트·키움은 등록된 IP에서만 API가 통해서, 장소를 옮기면 그 장소의
     * 키로 바꿔야 한다. 설정 화면까지 들어가지 않고 여기서 바로 바꾼다.
     * 키를 바꾸면 엔진이 새 설정으로 다시 뜬다(잠깐 화면이 빌 수 있다).
     */
    private fun showKeyPicker() {
        val broker = Brokers.ALL.firstOrNull { it.id == shown } ?: active.firstOrNull() ?: return
        val vault = Vault(this)
        val count = vault.slotCount(broker)
        if (count <= 1) {
            toast("${broker.label}에 저장된 키가 하나뿐입니다.\n설정에서 추가할 수 있습니다.")
            return
        }
        val cur = vault.activeSlot(broker)
        val names = (0 until count).map { vault.slotLabel(broker, it) }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("${broker.label} 키 선택")
            .setSingleChoiceItems(names, cur) { d, which ->
                d.dismiss()
                if (which == cur) return@setSingleChoiceItems
                vault.setActiveSlot(broker, which)
                toast("'${names[which]}' 키로 바꿉니다. 엔진을 다시 시작합니다.")
                // .env 가 바뀌면 엔진 프로세스가 스스로 재시작한다.
                lifecycleScope.launch {
                    withContext(Dispatchers.IO) {
                        runCatching { EngineHost.startEnabled(this@MainActivity) }
                    }
                    markUp(broker, false)
                    panes[broker.id]?.paneEmpty?.visibility = View.VISIBLE
                    panes[broker.id]?.paneEmpty?.text = "키를 바꿔 엔진을 다시 시작하는 중…"
                    waitForEngines()
                }
            }
            .setNegativeButton("취소", null)
            .show()
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    // ---- 작은 HTTP 도우미 ----
    private fun getJson(url: String): JSONObject {
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 4000
            readTimeout = 4000
        }
        val text = c.inputStream.bufferedReader().use(BufferedReader::readText)
        c.disconnect()
        return JSONObject(text)
    }

    private fun postJson(url: String, body: JSONObject) {
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            connectTimeout = 4000
            readTimeout = 4000
        }
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        c.inputStream.use { it.readBytes() }
        c.disconnect()
    }
}
