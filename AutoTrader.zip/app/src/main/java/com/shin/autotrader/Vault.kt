package com.shin.autotrader

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * 증권사 한 곳의 설정.
 *
 * 필드 이름은 각 증권사가 발급 화면에서 쓰는 말과 맞췄다. 사용자가 발급받은
 * 화면을 보면서 그대로 옮겨 적을 수 있어야 하기 때문이다.
 */
data class Broker(
    val id: String,
    val label: String,
    val port: Int,
    /** 계좌번호를 받는 곳인지 (업비트는 계좌 개념이 없다) */
    val needsAccount: Boolean,
    val keyLabel: String,
    val secretLabel: String,
    val guideTitle: String,
) {
    val url: String get() = "http://127.0.0.1:$port/"
}

object Brokers {
    val KIS = Broker(
        id = "kis", label = "한국투자증권", port = 8787, needsAccount = true,
        keyLabel = "APP KEY", secretLabel = "APP SECRET",
        guideTitle = "한국투자증권 Open API 키 발급받기",
    )
    // ⚠️ 키움 API는 '지정단말기'로 등록된 기기에서만 토큰 발급을 허용한다(오류 8050).
    // 폰이 고정 IP로 등록된 와이파이에 붙어 있어야 정상 동작한다.
    // 등록되지 않은 망(LTE/5G, 다른 와이파이)으로 넘어가면 토큰 재발급 시점부터
    // 8050이 나기 시작한다 — 그때는 코드가 아니라 접속 환경 문제다.
    val KIWOOM = Broker(
        id = "kiwoom", label = "키움증권", port = 8788, needsAccount = true,
        keyLabel = "앱 키 (App Key)", secretLabel = "앱 시크릿 (App Secret)",
        guideTitle = "키움증권 Open API 키 발급받기",
    )
    val UPBIT = Broker(
        id = "upbit", label = "업비트", port = 8789, needsAccount = false,
        keyLabel = "Access Key", secretLabel = "Secret Key",
        guideTitle = "업비트 Open API 키 발급받기",
    )
    val ALL = listOf(KIS, KIWOOM, UPBIT)
}

/** 사용자가 입력한 값. 계좌번호는 업비트에선 비어 있다. */
data class Credentials(
    val enabled: Boolean = false,
    val key: String = "",
    val secret: String = "",
    val account: String = "",
    /** 이 키 묶음의 이름. 장소를 적어두면 어느 키인지 바로 안다 (집/사무실 등) */
    val label: String = "",
) {
    /** 이 증권사를 실제로 켤 수 있는 상태인가 */
    fun isComplete(broker: Broker): Boolean =
        key.isNotBlank() && secret.isNotBlank() &&
            (!broker.needsAccount || account.isNotBlank())
}

/**
 * API 키 저장소.
 *
 * ⚠️ 평범한 SharedPreferences에 넣으면 루팅된 기기나 백업 파일에서 키가 그대로
 * 읽힌다. 증권사 키는 곧 주문 권한이라 반드시 암호화해서 둔다.
 * EncryptedSharedPreferences는 안드로이드 키스토어(하드웨어 보안 영역)에
 * 마스터키를 두고 값을 암호화한다.
 */
class Vault(context: Context) {

    companion object {
        /** 증권사당 저장할 수 있는 키 묶음 수 */
        const val MAX_SLOTS = 5
    }


    private val prefs: SharedPreferences = run {
        val master = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context,
            "autotrader_creds",
            master,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
        )
    }

    /**
     * 키 묶음(슬롯)을 여러 개 저장한다.
     *
     * ⚠️ 업비트·키움은 등록된 IP에서만 API가 통한다. 장소를 옮기면 그 장소의
     * IP로 발급한 다른 키가 필요한데, 매번 긴 문자열을 다시 붙여넣는 건
     * 번거롭고 오타도 난다. 장소별로 미리 저장해두고 버튼으로 바꾼다.
     *
     * ⚠️ 거래 기록은 슬롯이 아니라 '계좌번호' 기준으로 갈린다. 같은 계좌의
     * 키를 바꾸는 것뿐이면 보유 종목·거래 내역이 그대로 이어져야 하기 때문이다.
     * 슬롯마다 기록을 나누면 종목 추적이 끊긴다.
     */
    fun slotCount(broker: Broker): Int =
        prefs.getInt("${broker.id}_slots", 1).coerceIn(1, MAX_SLOTS)

    fun activeSlot(broker: Broker): Int =
        prefs.getInt("${broker.id}_active", 0).coerceIn(0, slotCount(broker) - 1)

    fun setActiveSlot(broker: Broker, slot: Int) {
        prefs.edit().putInt("${broker.id}_active", slot.coerceIn(0, slotCount(broker) - 1)).apply()
    }

    fun addSlot(broker: Broker): Int {
        val n = slotCount(broker)
        if (n >= MAX_SLOTS) return n - 1
        prefs.edit().putInt("${broker.id}_slots", n + 1).apply()
        return n
    }

    fun removeSlot(broker: Broker, slot: Int) {
        val n = slotCount(broker)
        if (n <= 1) {          // 마지막 하나는 지우지 않고 값만 비운다
            save(broker, Credentials(enabled = load(broker).enabled), 0)
            return
        }
        // 뒤의 슬롯을 앞으로 당겨서 빈칸이 생기지 않게 한다
        for (i in slot until n - 1) save(broker, load(broker, i + 1), i)
        prefs.edit().putInt("${broker.id}_slots", n - 1).apply()
        setActiveSlot(broker, activeSlot(broker).coerceAtMost(n - 2))
    }

    private fun k(broker: Broker, slot: Int, field: String) =
        if (slot == 0) "${broker.id}_$field" else "${broker.id}_s${slot}_$field"

    fun load(broker: Broker, slot: Int = -1): Credentials {
        val i = if (slot < 0) activeSlot(broker) else slot
        return Credentials(
            // 켜짐 여부는 증권사 단위다 (슬롯마다 켜고 끄지 않는다)
            enabled = prefs.getBoolean("${broker.id}_enabled", false),
            key = prefs.getString(k(broker, i, "key"), "") ?: "",
            secret = prefs.getString(k(broker, i, "secret"), "") ?: "",
            account = prefs.getString(k(broker, i, "account"), "") ?: "",
            label = prefs.getString(k(broker, i, "label"), "") ?: "",
        )
    }

    fun save(broker: Broker, c: Credentials, slot: Int = -1) {
        val i = if (slot < 0) activeSlot(broker) else slot
        prefs.edit()
            .putBoolean("${broker.id}_enabled", c.enabled)
            .putString(k(broker, i, "key"), c.key.trim())
            .putString(k(broker, i, "secret"), c.secret.trim())
            .putString(k(broker, i, "account"), c.account.trim())
            .putString(k(broker, i, "label"), c.label.trim())
            .apply()
    }

    fun clear(broker: Broker) {
        val e = prefs.edit().remove("${broker.id}_enabled")
        for (i in 0 until MAX_SLOTS) {
            for (f in listOf("key", "secret", "account", "label")) e.remove(k(broker, i, f))
        }
        e.remove("${broker.id}_slots").remove("${broker.id}_active").apply()
    }

    /** 화면에 보여줄 슬롯 이름. 비어 있으면 순번으로 대신한다. */
    fun slotLabel(broker: Broker, slot: Int): String {
        val l = load(broker, slot).label
        return if (l.isNotBlank()) l else "키 ${slot + 1}"
    }

    /** 실제로 켜져 있고 입력도 끝난 증권사들 */
    fun activeBrokers(): List<Broker> =
        Brokers.ALL.filter { load(it).let { c -> c.enabled && c.isComplete(it) } }
}
