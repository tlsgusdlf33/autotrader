package com.shin.autotrader

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * 증권사 한 곳의 설정.
 *
 * 필드 이름은 각 증권사가 발급 화면에서 쓰는 말과 맞췄다. 사용자가 발급받은
 * 화면을 보면서 그대로 옮겨 적을 수 있어야 하기 때문이다.
 */
data class Broker(
    val id: String,
    val label: String,
    val port: Int,
    /** 계좌번호를 받는 곳인지 (업비트는 계좌 개념이 없다) */
    val needsAccount: Boolean,
    val keyLabel: String,
    val secretLabel: String,
    val guideTitle: String,
) {
    val url: String get() = "http://127.0.0.1:$port/"
}

object Brokers {
    val KIS = Broker(
        id = "kis", label = "한국투자증권", port = 8787, needsAccount = true,
        keyLabel = "APP KEY", secretLabel = "APP SECRET",
        guideTitle = "한국투자증권 Open API 키 발급받기",
    )
    // ⚠️ 키움 API는 '지정단말기'로 등록된 기기에서만 토큰 발급을 허용한다(오류 8050).
    // 폰이 고정 IP로 등록된 와이파이에 붙어 있어야 정상 동작한다.
    // 등록되지 않은 망(LTE/5G, 다른 와이파이)으로 넘어가면 토큰 재발급 시점부터
    // 8050이 나기 시작한다 — 그때는 코드가 아니라 접속 환경 문제다.
    val KIWOOM = Broker(
        id = "kiwoom", label = "키움증권", port = 8788, needsAccount = true,
        keyLabel = "앱 키 (App Key)", secretLabel = "앱 시크릿 (App Secret)",
        guideTitle = "키움증권 Open API 키 발급받기",
    )
    val UPBIT = Broker(
        id = "upbit", label = "업비트", port = 8789, needsAccount = false,
        keyLabel = "Access Key", secretLabel = "Secret Key",
        guideTitle = "업비트 Open API 키 발급받기",
    )
    val ALL = listOf(KIS, KIWOOM, UPBIT)
}

/** 사용자가 입력한 값. 계좌번호는 업비트에선 비어 있다. */
data class Credentials(
    val enabled: Boolean = false,
    val key: String = "",
    val secret: String = "",
    val account: String = "",
) {
    /** 이 증권사를 실제로 켤 수 있는 상태인가 */
    fun isComplete(broker: Broker): Boolean =
        key.isNotBlank() && secret.isNotBlank() &&
            (!broker.needsAccount || account.isNotBlank())
}

/**
 * API 키 저장소.
 *
 * ⚠️ 평범한 SharedPreferences에 넣으면 루팅된 기기나 백업 파일에서 키가 그대로
 * 읽힌다. 증권사 키는 곧 주문 권한이라 반드시 암호화해서 둔다.
 * EncryptedSharedPreferences는 안드로이드 키스토어(하드웨어 보안 영역)에
 * 마스터키를 두고 값을 암호화한다.
 */
class Vault(context: Context) {

    private val prefs: SharedPreferences = run {
        val master = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context,
            "autotrader_creds",
            master,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
        )
    }

    fun load(broker: Broker): Credentials = Credentials(
        enabled = prefs.getBoolean("${broker.id}_enabled", false),
        key = prefs.getString("${broker.id}_key", "") ?: "",
        secret = prefs.getString("${broker.id}_secret", "") ?: "",
        account = prefs.getString("${broker.id}_account", "") ?: "",
    )

    fun save(broker: Broker, c: Credentials) {
        prefs.edit()
            .putBoolean("${broker.id}_enabled", c.enabled)
            .putString("${broker.id}_key", c.key.trim())
            .putString("${broker.id}_secret", c.secret.trim())
            .putString("${broker.id}_account", c.account.trim())
            .apply()
    }

    fun clear(broker: Broker) {
        prefs.edit()
            .remove("${broker.id}_enabled")
            .remove("${broker.id}_key")
            .remove("${broker.id}_secret")
            .remove("${broker.id}_account")
            .apply()
    }

    /** 실제로 켜져 있고 입력도 끝난 증권사들 */
    fun activeBrokers(): List<Broker> =
        Brokers.ALL.filter { load(it).let { c -> c.enabled && c.isComplete(it) } }
}
