package com.shin.autotrader

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.widget.AppCompatButton
import androidx.core.content.ContextCompat
import android.widget.LinearLayout
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.shin.autotrader.databinding.ActivitySetupBinding
import com.shin.autotrader.databinding.ItemBrokerBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * 첫 화면. 어느 증권사를 켤지 고르고, 각각의 API 키와 계좌번호를 넣는다.
 *
 * 값은 언제든 다시 열어 고칠 수 있다 — 저장된 값이 있으면 그대로 채워 보여준다.
 * 키는 화면에서 가려두되(●●●), 눈 버튼으로 확인할 수 있게 한다. 긴 문자열을
 * 옮겨 적을 때 오타를 확인할 방법이 없으면 사용자가 원인을 못 찾는다.
 */
class SetupActivity : AppCompatActivity() {

    private lateinit var b: ActivitySetupBinding
    private lateinit var vault: Vault
    private val rows = mutableMapOf<String, ItemBrokerBinding>()

    /**
     * 백업에서 되살리는 중인가.
     *
     * ⚠️ 되살리는 동안에는 onPause 저장을 건너뛴다. 되살리기는 배경에서 도는데,
     * 그 사이 화면을 떠나면 아직 비어 있는 입력칸이 저장되면서 방금 되살린
     * 값을 덮어쓴다.
     */
    private var restoring = false

    /** 사용자가 고른 백업 파일로 되살린다 (자동 복구가 안 될 때의 마지막 수단) */
    private val pickBackup = registerForActivityResult(
        ActivityResultContracts.OpenDocument(),
    ) { uri: Uri? -> if (uri != null) restoreFromFile(uri) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivitySetupBinding.inflate(layoutInflater)
        setContentView(b.root)
        vault = Vault(this)

        Brokers.ALL.forEach { broker ->
            val row = ItemBrokerBinding.inflate(layoutInflater, b.brokerList, true)
            rows[broker.id] = row
            bind(broker, row)
        }

        b.btnGuide.setOnClickListener {
            startActivity(Intent(this, GuideActivity::class.java))
        }
        b.btnUpdate.setOnClickListener { showUpdateMenu() }
        b.btnBackup.setOnClickListener { showBackupMenu() }
        b.btnEnter.setOnClickListener { enter() }

        restoreIfFirstRun()
    }

    override fun onResume() {
        super.onResume()
        // 안내 화면에 다녀와도 입력하던 값이 그대로 남아 있어야 한다
        Brokers.ALL.forEach { rows[it.id]?.let { row -> fill(it, row) } }
    }

    /**
     * 화면을 떠날 때 입력한 값을 저장한다.
     *
     * ⚠️ 예전에는 '시작하기'를 눌러야만 저장됐다. 키를 다 붙여넣고 홈 버튼을
     * 누르거나 다른 앱을 보고 오면, 안드로이드가 그 사이 앱을 정리해버려서
     * 입력한 내용이 통째로 사라졌다 — "키를 넣었는데 반영이 안 된다"는 것이
     * 이 경우였다. 화면을 벗어나는 순간마다 저장해 두면 그럴 일이 없다.
     */
    override fun onPause() {
        super.onPause()
        if (restoring) return
        Brokers.ALL.forEach { rows[it.id]?.let { row -> save(it, row) } }
    }

    private fun bind(broker: Broker, row: ItemBrokerBinding) {
        row.brokerName.text = broker.label
        row.brokerPort.text = broker.port.toString()
        row.keyInput.hint = broker.keyLabel
        row.secretInput.hint = broker.secretLabel
        row.accountInput.hint = "계좌번호 (8자리)"
        row.accountInput.visibility = if (broker.needsAccount) View.VISIBLE else View.GONE

        fill(broker, row)

        row.brokerSwitch.setOnCheckedChangeListener { _, on ->
            row.fields.visibility = if (on) View.VISIBLE else View.GONE
            save(broker, row)
        }
        row.btnShow.setOnClickListener {
            val hidden = row.secretInput.inputType and InputType.TYPE_TEXT_VARIATION_PASSWORD != 0
            val type = if (hidden) InputType.TYPE_CLASS_TEXT
            else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            row.keyInput.inputType = type
            row.secretInput.inputType = type
            row.btnShow.text = if (hidden) "가리기" else "보기"
            row.keyInput.setSelection(row.keyInput.text.length)
            row.secretInput.setSelection(row.secretInput.text.length)
        }
        row.btnClear.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("${broker.label} 입력값을 지울까요?")
                .setMessage("저장된 키와 계좌번호가 이 기기에서 삭제됩니다.")
                .setPositiveButton("지우기") { _, _ ->
                    vault.clear(broker)
                    row.keyInput.setText("")
                    row.secretInput.setText("")
                    row.accountInput.setText("")
                    row.brokerSwitch.isChecked = false
                }
                .setNegativeButton("취소", null)
                .show()
        }
    }

    /**
     * 저장된 값을 화면에 채운다.
     *
     * 평소에는 비어 있는 칸만 채운다 — 안내 화면에 다녀오는 사이 입력하던 값이
     * 지워지면 안 되기 때문이다. 백업에서 되살린 직후에는 화면에 남은 빈 값이
     * 아니라 저장된 값이 맞으므로 force 로 전부 다시 채운다.
     */
    private fun fill(broker: Broker, row: ItemBrokerBinding, force: Boolean = false) {
        val c = vault.load(broker)
        renderSlots(broker, row)
        row.brokerSwitch.isChecked = c.enabled
        row.fields.visibility = if (c.enabled) View.VISIBLE else View.GONE
        if (force || row.keyInput.text.isEmpty()) row.keyInput.setText(c.key)
        if (force || row.secretInput.text.isEmpty()) row.secretInput.setText(c.secret)
        if (force || row.accountInput.text.isEmpty()) row.accountInput.setText(c.account)
        if (force || row.labelInput.text.isEmpty()) row.labelInput.setText(c.label)
    }

    private fun save(broker: Broker, row: ItemBrokerBinding) {
        vault.save(
            broker,
            Credentials(
                enabled = row.brokerSwitch.isChecked,
                key = row.keyInput.text.toString(),
                secret = row.secretInput.text.toString(),
                account = row.accountInput.text.toString(),
                label = row.labelInput.text.toString(),
            ),
        )
    }

    /**
     * 키 묶음(슬롯) 버튼들을 그린다.
     *
     * ⚠️ 업비트·키움은 등록된 IP에서만 API가 통해서, 장소를 옮기면 그 장소의
     * 키가 필요하다. 매번 긴 문자열을 붙여넣는 대신 미리 저장해두고 고른다.
     * 거래 기록은 계좌번호 기준으로 갈리므로, 같은 계좌의 키를 바꾸는 것뿐이면
     * 보유 종목·거래 내역은 그대로 이어진다.
     */
    private fun renderSlots(broker: Broker, row: ItemBrokerBinding) {
        row.slotBar.removeAllViews()
        val active = vault.activeSlot(broker)
        val count = vault.slotCount(broker)

        for (i in 0 until count) {
            val btn = AppCompatButton(this).apply {
                text = vault.slotLabel(broker, i)
                isAllCaps = false
                textSize = 12f
                minWidth = 0
                minimumWidth = 0
                setPadding(28, 12, 28, 12)
                setBackgroundResource(
                    if (i == active) R.drawable.bg_pill_on else R.drawable.bg_pill,
                )
                setTextColor(
                    ContextCompat.getColor(
                        this@SetupActivity,
                        if (i == active) R.color.accent else R.color.muted,
                    ),
                )
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                ).also { if (i > 0) it.marginStart = 6 }
                setOnClickListener {
                    // 지금 화면의 값을 먼저 저장하고 나서 슬롯을 바꾼다.
                    // 안 그러면 입력하던 내용이 사라진다.
                    save(broker, row)
                    vault.setActiveSlot(broker, i)
                    val c = vault.load(broker)
                    row.keyInput.setText(c.key)
                    row.secretInput.setText(c.secret)
                    row.accountInput.setText(c.account)
                    row.labelInput.setText(c.label)
                    renderSlots(broker, row)
                }
                setOnLongClickListener {
                    confirmRemoveSlot(broker, row, i)
                    true
                }
            }
            row.slotBar.addView(btn)
        }

        if (count < Vault.MAX_SLOTS) {
            val add = AppCompatButton(this).apply {
                text = "+"
                isAllCaps = false
                textSize = 13f
                minWidth = 0
                minimumWidth = 0
                setPadding(28, 12, 28, 12)
                setBackgroundResource(R.drawable.bg_pill)
                setTextColor(ContextCompat.getColor(this@SetupActivity, R.color.text))
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                ).also { it.marginStart = 6 }
                setOnClickListener {
                    save(broker, row)
                    val n = vault.addSlot(broker)
                    vault.setActiveSlot(broker, n)
                    row.keyInput.setText("")
                    row.secretInput.setText("")
                    row.accountInput.setText("")
                    row.labelInput.setText("")
                    renderSlots(broker, row)
                    toast("빈 키 묶음을 추가했습니다. 이름과 키를 넣어주세요.")
                }
            }
            row.slotBar.addView(add)
        }
    }

    private fun confirmRemoveSlot(broker: Broker, row: ItemBrokerBinding, slot: Int) {
        AlertDialog.Builder(this)
            .setTitle("'${vault.slotLabel(broker, slot)}' 를 지울까요?")
            .setMessage("저장된 키가 이 기기에서 삭제됩니다.")
            .setPositiveButton("지우기") { _, _ ->
                vault.removeSlot(broker, slot)
                val c = vault.load(broker)
                row.keyInput.setText(c.key)
                row.secretInput.setText(c.secret)
                row.accountInput.setText(c.account)
                row.labelInput.setText(c.label)
                renderSlots(broker, row)
            }
            .setNegativeButton("취소", null)
            .show()
    }

    private fun enter() {
        Brokers.ALL.forEach { rows[it.id]?.let { row -> save(it, row) } }

        val on = Brokers.ALL.filter { vault.load(it).enabled }
        if (on.isEmpty()) {
            toast("실행할 증권사를 하나 이상 켜주세요")
            return
        }
        // 켜뒀는데 입력이 덜 된 곳을 먼저 짚어준다. 그냥 넘어가면 다음 화면이
        // 빈 채로 뜨고, 사용자는 어디가 문제인지 알 수 없다.
        val incomplete = on.filter { !vault.load(it).isComplete(it) }
        if (incomplete.isNotEmpty()) {
            toast("${incomplete.joinToString { it.label }}의 입력이 덜 되었습니다")
            return
        }

        // 방금 넣은 키를 앱 폴더 밖에도 한 벌 남긴다. 앱을 지우더라도
        // 다시 깔았을 때 스스로 되살릴 수 있게 하기 위해서다.
        Backup.saveAsync(this)

        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    // ──────────────────────────────────────────────────────────
    // 백업에서 되살리기
    // ──────────────────────────────────────────────────────────

    /**
     * 앱을 새로 깔았을 때 이전 설정을 스스로 되살린다.
     *
     * ⚠️ 키가 하나도 없을 때만 돈다. 쓰던 값이 있는데 백업으로 덮으면 방금
     * 바꾼 내용이 사라진다.
     *
     * 되살아나는 것: API 키·계좌번호·키 묶음, 그리고 엔진 거래 기록
     * (engine_state.db) — 어떤 종목을 어떤 매매법으로 샀는지가 여기 들어있다.
     */
    private fun restoreIfFirstRun() {
        if (vault.hasAnyCredentials()) return
        restoring = true
        lifecycleScope.launch {
            val ok = try {
                withContext(Dispatchers.IO) {
                    runCatching { Backup.autoRestoreIfEmpty(this@SetupActivity) }.getOrDefault(false)
                }
            } finally {
                restoring = false
            }
            if (!ok) return@launch
            Brokers.ALL.forEach { broker -> rows[broker.id]?.let { fill(broker, it, force = true) } }
            AlertDialog.Builder(this@SetupActivity)
                .setTitle("이전 설정을 되살렸습니다")
                .setMessage(
                    "백업에서 API 키와 거래 기록을 되살렸습니다.\n" +
                        "이전에 매수한 종목의 매매법도 그대로 이어집니다.\n\n" +
                        "값이 맞는지 한 번 확인한 뒤 시작해주세요.",
                )
                .setPositiveButton("확인", null)
                .show()
        }
    }

    /**
     * 백업 메뉴.
     *
     * 평소에는 앱이 알아서 백업하고 알아서 되살리므로 열 일이 없다.
     * 자동 복구가 안 되는 경우가 하나 있어서 남겨둔다 — 안드로이드 10부터는
     * 앱을 지우면 그 앱이 다운로드 폴더에 만든 파일의 소유권이 끊겨서, 다시
     * 깔았을 때 코드로는 읽지 못한다. 그때는 여기서 파일을 직접 고르면 된다.
     */
    private fun showBackupMenu() {
        AlertDialog.Builder(this)
            .setTitle("설정 백업")
            .setMessage(
                "API 키와 거래 기록(어떤 매매법으로 샀는지 포함)을 암호화해서 " +
                    "다운로드 폴더의 AutoTrader 안에 보관합니다.\n" +
                    "앱을 새로 깔면 자동으로 되살리며, 안 될 때만 파일을 직접 고르면 됩니다.",
            )
            .setPositiveButton("지금 백업") { _, _ ->
                Brokers.ALL.forEach { rows[it.id]?.let { row -> save(it, row) } }
                lifecycleScope.launch {
                    val ok = withContext(Dispatchers.IO) { Backup.save(this@SetupActivity) }
                    toast(if (ok) "백업했습니다 (다운로드/AutoTrader)" else "백업에 실패했습니다")
                }
            }
            .setNeutralButton("파일에서 되살리기") { _, _ -> pickBackup.launch(arrayOf("*/*")) }
            .setNegativeButton("닫기", null)
            .show()
    }

    private fun restoreFromFile(uri: Uri) {
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching { Backup.restoreFrom(this@SetupActivity, uri) }
            }
            result.onSuccess { ok ->
                if (!ok) {
                    toast("백업 파일에서 설정을 찾지 못했습니다")
                    return@onSuccess
                }
                Brokers.ALL.forEach { broker -> rows[broker.id]?.let { fill(broker, it, force = true) } }
                toast("백업에서 되살렸습니다")
            }.onFailure {
                AlertDialog.Builder(this@SetupActivity)
                    .setTitle("되살리지 못했습니다")
                    .setMessage(it.message ?: "알 수 없는 오류")
                    .setPositiveButton("확인", null)
                    .show()
            }
        }
    }

    /**
     * 자동 업데이트 상태와 조작.
     *
     * ⚠️ 두 갈래를 구분해서 보여준다. 매매 로직(파이썬 엔진)은 설치 없이
     * 자동으로 바뀌고, 화면·서비스(APK)는 안드로이드가 설치 확인을 받으므로
     * 탭 한 번이 필요하다. 이 구분을 모르면 "자동이라더니 왜 물어보냐"가 된다.
     */
    private fun showUpdateMenu() {
        val auto = Updater.isAuto(this)
        val bundle = Updater.engineBundle(this)
        val installed = Updater.appVersionCode(this)
        val pending = Updater.pendingApk(this) != null

        val msg = StringBuilder()
        msg.append("자동 업데이트: ${if (auto) "켜짐" else "꺼짐"}\n")
        msg.append("설치된 앱 버전: 1.0.$installed\n")
        msg.append("매매 로직 버전: b$bundle")
        if (bundle > installed) msg.append(" (자동으로 새로 받은 것)")
        msg.append("\n\n매매 로직은 설치 없이 알아서 새것으로 바뀝니다.\n")
        msg.append("화면·알림 같은 앱 자체 변경은 안드로이드가 설치 확인을 받게 되어 있어 ")
        msg.append("탭 한 번이 필요합니다.")
        if (pending) msg.append("\n\n▶ 받아둔 새 버전이 있습니다 — '설치'를 눌러주세요.")

        val dialog = AlertDialog.Builder(this)
            .setTitle("자동 업데이트")
            .setMessage(msg.toString())
            .setPositiveButton(if (pending) "설치" else "지금 확인") { _, _ ->
                if (pending) {
                    if (!Updater.installPendingApk(this)) toast("설치 화면을 띄우지 못했습니다")
                } else {
                    toast("확인 중…")
                    Updater.checkAsync(this, force = true) { r ->
                        runOnUiThread {
                            toast(when {
                                r.error.isNotBlank() -> r.error
                                r.apkReady -> "새 버전 ${r.latestVersion} 을 받았습니다 — 다시 열어 설치해주세요"
                                r.engineUpdated -> "매매 로직을 새로 받았습니다 — 엔진 재시작 시 적용됩니다"
                                r.checked -> "이미 최신입니다"
                                else -> "확인했습니다"
                            })
                        }
                    }
                }
            }
            .setNeutralButton(if (auto) "자동 끄기" else "자동 켜기") { _, _ ->
                Updater.setAuto(this, !auto)
                toast(if (auto) "자동 업데이트를 껐습니다" else "자동 업데이트를 켰습니다")
            }
            .setNegativeButton("닫기", null)
            .create()
        dialog.show()
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
}
