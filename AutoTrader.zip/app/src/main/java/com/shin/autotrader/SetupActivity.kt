package com.shin.autotrader

import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.shin.autotrader.databinding.ActivitySetupBinding
import com.shin.autotrader.databinding.ItemBrokerBinding

/**
 * 첫 화면. 어느 증권사를 켤지 고르고, 각각의 API 키와 계좌번호를 넣는다.
 *
 * 값은 언제든 다시 열어 고칠 수 있다 — 저장된 값이 있으면 그대로 채워 보여준다.
 * 키는 화면에서 가려두되(●●●), 눈 버튼으로 확인할 수 있게 한다. 긴 문자열을
 * 옮겨 적을 때 오타를 확인할 방법이 없으면 사용자가 원인을 못 찾는다.
 */
class SetupActivity : AppCompatActivity() {

    private lateinit var b: ActivitySetupBinding
    private lateinit var vault: Vault
    private val rows = mutableMapOf<String, ItemBrokerBinding>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivitySetupBinding.inflate(layoutInflater)
        setContentView(b.root)
        vault = Vault(this)

        Brokers.ALL.forEach { broker ->
            val row = ItemBrokerBinding.inflate(layoutInflater, b.brokerList, true)
            rows[broker.id] = row
            bind(broker, row)
        }

        b.btnGuide.setOnClickListener {
            startActivity(Intent(this, GuideActivity::class.java))
        }
        b.btnEnter.setOnClickListener { enter() }
    }

    override fun onResume() {
        super.onResume()
        // 안내 화면에 다녀와도 입력하던 값이 그대로 남아 있어야 한다
        Brokers.ALL.forEach { rows[it.id]?.let { row -> fill(it, row) } }
    }

    private fun bind(broker: Broker, row: ItemBrokerBinding) {
        row.brokerName.text = broker.label
        row.brokerPort.text = broker.port.toString()
        row.keyInput.hint = broker.keyLabel
        row.secretInput.hint = broker.secretLabel
        row.accountInput.hint = "계좌번호 (8자리)"
        row.accountInput.visibility = if (broker.needsAccount) View.VISIBLE else View.GONE

        fill(broker, row)

        row.brokerSwitch.setOnCheckedChangeListener { _, on ->
            row.fields.visibility = if (on) View.VISIBLE else View.GONE
            save(broker, row)
        }
        row.btnShow.setOnClickListener {
            val hidden = row.secretInput.inputType and InputType.TYPE_TEXT_VARIATION_PASSWORD != 0
            val type = if (hidden) InputType.TYPE_CLASS_TEXT
            else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            row.keyInput.inputType = type
            row.secretInput.inputType = type
            row.btnShow.text = if (hidden) "가리기" else "보기"
            row.keyInput.setSelection(row.keyInput.text.length)
            row.secretInput.setSelection(row.secretInput.text.length)
        }
        row.btnClear.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("${broker.label} 입력값을 지울까요?")
                .setMessage("저장된 키와 계좌번호가 이 기기에서 삭제됩니다.")
                .setPositiveButton("지우기") { _, _ ->
                    vault.clear(broker)
                    row.keyInput.setText("")
                    row.secretInput.setText("")
                    row.accountInput.setText("")
                    row.brokerSwitch.isChecked = false
                }
                .setNegativeButton("취소", null)
                .show()
        }
    }

    private fun fill(broker: Broker, row: ItemBrokerBinding) {
        val c = vault.load(broker)
        row.brokerSwitch.isChecked = c.enabled
        row.fields.visibility = if (c.enabled) View.VISIBLE else View.GONE
        if (row.keyInput.text.isEmpty()) row.keyInput.setText(c.key)
        if (row.secretInput.text.isEmpty()) row.secretInput.setText(c.secret)
        if (row.accountInput.text.isEmpty()) row.accountInput.setText(c.account)
    }

    private fun save(broker: Broker, row: ItemBrokerBinding) {
        vault.save(
            broker,
            Credentials(
                enabled = row.brokerSwitch.isChecked,
                key = row.keyInput.text.toString(),
                secret = row.secretInput.text.toString(),
                account = row.accountInput.text.toString(),
            ),
        )
    }

    private fun enter() {
        Brokers.ALL.forEach { rows[it.id]?.let { row -> save(it, row) } }

        val on = Brokers.ALL.filter { vault.load(it).enabled }
        if (on.isEmpty()) {
            toast("실행할 증권사를 하나 이상 켜주세요")
            return
        }
        // 켜뒀는데 입력이 덜 된 곳을 먼저 짚어준다. 그냥 넘어가면 다음 화면이
        // 빈 채로 뜨고, 사용자는 어디가 문제인지 알 수 없다.
        val incomplete = on.filter { !vault.load(it).isComplete(it) }
        if (incomplete.isNotEmpty()) {
            toast("${incomplete.joinToString { it.label }}의 입력이 덜 되었습니다")
            return
        }

        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
}
