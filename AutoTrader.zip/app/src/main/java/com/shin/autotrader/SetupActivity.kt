package com.shin.autotrader

import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.Toast
import androidx.appcompat.widget.AppCompatButton
import androidx.core.content.ContextCompat
import android.widget.LinearLayout
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.shin.autotrader.databinding.ActivitySetupBinding
import com.shin.autotrader.databinding.ItemBrokerBinding

/**
 * 첫 화면. 어느 증권사를 켤지 고르고, 각각의 API 키와 계좌번호를 넣는다.
 *
 * 값은 언제든 다시 열어 고칠 수 있다 — 저장된 값이 있으면 그대로 채워 보여준다.
 * 키는 화면에서 가려두되(●●●), 눈 버튼으로 확인할 수 있게 한다. 긴 문자열을
 * 옮겨 적을 때 오타를 확인할 방법이 없으면 사용자가 원인을 못 찾는다.
 */
class SetupActivity : AppCompatActivity() {

    private lateinit var b: ActivitySetupBinding
    private lateinit var vault: Vault
    private val rows = mutableMapOf<String, ItemBrokerBinding>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivitySetupBinding.inflate(layoutInflater)
        setContentView(b.root)
        vault = Vault(this)

        Brokers.ALL.forEach { broker ->
            val row = ItemBrokerBinding.inflate(layoutInflater, b.brokerList, true)
            rows[broker.id] = row
            bind(broker, row)
        }

        b.btnGuide.setOnClickListener {
            startActivity(Intent(this, GuideActivity::class.java))
        }
        b.btnEnter.setOnClickListener { enter() }
    }

    override fun onResume() {
        super.onResume()
        // 안내 화면에 다녀와도 입력하던 값이 그대로 남아 있어야 한다
        Brokers.ALL.forEach { rows[it.id]?.let { row -> fill(it, row) } }
    }

    private fun bind(broker: Broker, row: ItemBrokerBinding) {
        row.brokerName.text = broker.label
        row.brokerPort.text = broker.port.toString()
        row.keyInput.hint = broker.keyLabel
        row.secretInput.hint = broker.secretLabel
        row.accountInput.hint = "계좌번호 (8자리)"
        row.accountInput.visibility = if (broker.needsAccount) View.VISIBLE else View.GONE

        fill(broker, row)

        row.brokerSwitch.setOnCheckedChangeListener { _, on ->
            row.fields.visibility = if (on) View.VISIBLE else View.GONE
            save(broker, row)
        }
        row.btnShow.setOnClickListener {
            val hidden = row.secretInput.inputType and InputType.TYPE_TEXT_VARIATION_PASSWORD != 0
            val type = if (hidden) InputType.TYPE_CLASS_TEXT
            else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            row.keyInput.inputType = type
            row.secretInput.inputType = type
            row.btnShow.text = if (hidden) "가리기" else "보기"
            row.keyInput.setSelection(row.keyInput.text.length)
            row.secretInput.setSelection(row.secretInput.text.length)
        }
        row.btnClear.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("${broker.label} 입력값을 지울까요?")
                .setMessage("저장된 키와 계좌번호가 이 기기에서 삭제됩니다.")
                .setPositiveButton("지우기") { _, _ ->
                    vault.clear(broker)
                    row.keyInput.setText("")
                    row.secretInput.setText("")
                    row.accountInput.setText("")
                    row.brokerSwitch.isChecked = false
                }
                .setNegativeButton("취소", null)
                .show()
        }
    }

    private fun fill(broker: Broker, row: ItemBrokerBinding) {
        val c = vault.load(broker)
        row.labelInput.setText(c.label)
        renderSlots(broker, row)
        row.brokerSwitch.isChecked = c.enabled
        row.fields.visibility = if (c.enabled) View.VISIBLE else View.GONE
        if (row.keyInput.text.isEmpty()) row.keyInput.setText(c.key)
        if (row.secretInput.text.isEmpty()) row.secretInput.setText(c.secret)
        if (row.accountInput.text.isEmpty()) row.accountInput.setText(c.account)
        if (row.labelInput.text.isEmpty()) row.labelInput.setText(c.label)
    }

    private fun save(broker: Broker, row: ItemBrokerBinding) {
        vault.save(
            broker,
            Credentials(
                enabled = row.brokerSwitch.isChecked,
                key = row.keyInput.text.toString(),
                secret = row.secretInput.text.toString(),
                account = row.accountInput.text.toString(),
                label = row.labelInput.text.toString(),
            ),
        )
    }

    /**
     * 키 묶음(슬롯) 버튼들을 그린다.
     *
     * ⚠️ 업비트·키움은 등록된 IP에서만 API가 통해서, 장소를 옮기면 그 장소의
     * 키가 필요하다. 매번 긴 문자열을 붙여넣는 대신 미리 저장해두고 고른다.
     * 거래 기록은 계좌번호 기준으로 갈리므로, 같은 계좌의 키를 바꾸는 것뿐이면
     * 보유 종목·거래 내역은 그대로 이어진다.
     */
    private fun renderSlots(broker: Broker, row: ItemBrokerBinding) {
        row.slotBar.removeAllViews()
        val active = vault.activeSlot(broker)
        val count = vault.slotCount(broker)

        for (i in 0 until count) {
            val btn = AppCompatButton(this).apply {
                text = vault.slotLabel(broker, i)
                isAllCaps = false
                textSize = 12f
                minWidth = 0
                minimumWidth = 0
                setPadding(28, 12, 28, 12)
                setBackgroundResource(
                    if (i == active) R.drawable.bg_pill_on else R.drawable.bg_pill,
                )
                setTextColor(
                    ContextCompat.getColor(
                        this@SetupActivity,
                        if (i == active) R.color.accent else R.color.muted,
                    ),
                )
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                ).also { if (i > 0) it.marginStart = 6 }
                setOnClickListener {
                    // 지금 화면의 값을 먼저 저장하고 나서 슬롯을 바꾼다.
                    // 안 그러면 입력하던 내용이 사라진다.
                    save(broker, row)
                    vault.setActiveSlot(broker, i)
                    val c = vault.load(broker)
                    row.keyInput.setText(c.key)
                    row.secretInput.setText(c.secret)
                    row.accountInput.setText(c.account)
                    row.labelInput.setText(c.label)
                    renderSlots(broker, row)
                }
                setOnLongClickListener {
                    confirmRemoveSlot(broker, row, i)
                    true
                }
            }
            row.slotBar.addView(btn)
        }

        if (count < Vault.MAX_SLOTS) {
            val add = AppCompatButton(this).apply {
                text = "+"
                isAllCaps = false
                textSize = 13f
                minWidth = 0
                minimumWidth = 0
                setPadding(28, 12, 28, 12)
                setBackgroundResource(R.drawable.bg_pill)
                setTextColor(ContextCompat.getColor(this@SetupActivity, R.color.text))
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                ).also { it.marginStart = 6 }
                setOnClickListener {
                    save(broker, row)
                    val n = vault.addSlot(broker)
                    vault.setActiveSlot(broker, n)
                    row.keyInput.setText("")
                    row.secretInput.setText("")
                    row.accountInput.setText("")
                    row.labelInput.setText("")
                    renderSlots(broker, row)
                    toast("빈 키 묶음을 추가했습니다. 이름과 키를 넣어주세요.")
                }
            }
            row.slotBar.addView(add)
        }
    }

    private fun confirmRemoveSlot(broker: Broker, row: ItemBrokerBinding, slot: Int) {
        AlertDialog.Builder(this)
            .setTitle("'${vault.slotLabel(broker, slot)}' 를 지울까요?")
            .setMessage("저장된 키가 이 기기에서 삭제됩니다.")
            .setPositiveButton("지우기") { _, _ ->
                vault.removeSlot(broker, slot)
                val c = vault.load(broker)
                row.keyInput.setText(c.key)
                row.secretInput.setText(c.secret)
                row.accountInput.setText(c.account)
                row.labelInput.setText(c.label)
                renderSlots(broker, row)
            }
            .setNegativeButton("취소", null)
            .show()
    }

    private fun enter() {
        Brokers.ALL.forEach { rows[it.id]?.let { row -> save(it, row) } }

        val on = Brokers.ALL.filter { vault.load(it).enabled }
        if (on.isEmpty()) {
            toast("실행할 증권사를 하나 이상 켜주세요")
            return
        }
        // 켜뒀는데 입력이 덜 된 곳을 먼저 짚어준다. 그냥 넘어가면 다음 화면이
        // 빈 채로 뜨고, 사용자는 어디가 문제인지 알 수 없다.
        val incomplete = on.filter { !vault.load(it).isComplete(it) }
        if (incomplete.isNotEmpty()) {
            toast("${incomplete.joinToString { it.label }}의 입력이 덜 되었습니다")
            return
        }

        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
}
