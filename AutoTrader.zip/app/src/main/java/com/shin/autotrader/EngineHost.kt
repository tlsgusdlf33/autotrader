package com.shin.autotrader

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import java.io.File
import java.io.RandomAccessFile

/**
 * 엔진 프로세스들을 준비하고 띄운다.
 *
 * 역할 분담:
 *   여기(주 프로세스) — 엔진 소스 풀기 + .env 쓰기 + 서비스 시작
 *   각 서비스(별도 프로세스) — 파이썬을 켜서 자기 엔진 하나만 실행
 *
 * ⚠️ .env 를 서비스가 아니라 여기서 쓰는 이유: API 키는 암호화 저장소
 * (EncryptedSharedPreferences)에 있는데, 이건 여러 프로세스에서 동시에 읽고
 * 쓰면 안전하지 않다. 키를 다루는 건 주 프로세스 한 곳으로 모은다.
 */
object EngineHost {

    fun startEnabled(ctx: Context) {
        val vault = Vault(ctx)
        val root = File(ctx.filesDir, "engines")
        cleanupRemoved(root)
        // ⚠️ 한꺼번에 띄우지 않고 시차를 둔다.
        // 프로세스마다 파이썬을 처음 켜면서 pandas·numpy를 통째로 읽어들이는데,
        // 셋이 동시에 하면 폰의 CPU와 저장장치를 서로 뺏느라 전부 느려진다.
        // 설정을 바꿨는지 먼저 판별한다. 이미 돌고 있는 엔진에 시차를 두면
        // 설정 변경 후 화면이 돌아오는 데 30초씩 걸려 멈춘 것처럼 보인다.
        val changed = vault.activeBrokers().map { broker ->
            Assets.unpackIfNeeded(ctx, root, broker.id)
            val envFile = File(File(root, broker.id), ".env")
            val before = if (envFile.exists()) envFile.readText() else ""
            writeEnv(root, broker, vault.load(broker))
            broker to (envFile.readText() != before)
        }

        // 시차는 '처음 띄우는 엔진'에만 필요하다. 프로세스마다 파이썬을 처음
        // 켜면서 pandas·numpy를 통째로 읽어들이는데, 셋이 동시에 하면 폰의
        // CPU와 저장장치를 서로 뺏느라 전부 느려진다.
        var firstStarts = 0
        changed.forEach { (broker, envChanged) ->
            val running = Health.isUp(broker, timeoutMs = 800)
            if (!running || envChanged) {
                if (!running && firstStarts > 0) Thread.sleep(15_000)
                if (!running) firstStarts++
            }
            ContextCompat.startForegroundService(ctx, serviceIntent(ctx, broker))
        }
    }

    /**
     * 더 이상 쓰지 않는 엔진 폴더를 지운다.
     *
     * 키움을 앱에서 뺐지만, 이미 설치해서 쓰던 폰에는 engines/kiwoom 폴더가
     * 남아 있다. 그대로 두면 저장공간만 차지하고, 나중에 목록을 되살렸을 때
     * 옛 코드가 섞일 수 있다.
     */
    private fun cleanupRemoved(root: File) {
        val alive = Brokers.ALL.map { it.id }.toSet()
        root.listFiles()?.forEach { dir ->
            if (dir.isDirectory && dir.name !in alive) {
                runCatching { dir.deleteRecursively() }
            }
        }
    }

    fun stopAll(ctx: Context) {
        Brokers.ALL.forEach { ctx.stopService(serviceIntent(ctx, it)) }
    }

    private fun serviceIntent(ctx: Context, broker: Broker) = Intent(
        ctx,
        when (broker.id) {
            "kis" -> KisEngineService::class.java
            "kiwoom" -> KiwoomEngineService::class.java
            else -> UpbitEngineService::class.java
        },
    )

    /**
     * 사용자가 입력한 키로 .env 를 만든다.
     *
     * ⚠️ 앱 전용 폴더(filesDir) 안에만 쓴다. 다른 앱이 읽을 수 없는 위치다.
     * 외부 저장소에 쓰면 파일 관리자로 키가 그대로 보인다.
     */
    private fun writeEnv(root: File, broker: Broker, c: Credentials) {
        val dir = File(root, broker.id).apply { mkdirs() }
        val lines = mutableListOf(
            "WEB_PORT=${broker.port}",
            // 폰 안에서만 접근하게 묶는다. 0.0.0.0 으로 열면 같은 와이파이의
            // 다른 기기가 대시보드에 들어올 수 있다.
            "WEB_HOST=127.0.0.1",
            "DASHBOARD_PIN=",
        )
        when (broker.id) {
            // ⚠️ 계좌별로 거래 기록을 갈라둔다.
            // 예전에는 계좌를 바꿔도 engines/kis/state/ 를 그대로 썼다. 그러면
            // 이전 계좌에서 추적하던 종목이 새 계좌 화면에 '모르는 종목'으로
            // 뜨고, 반대로 새 계좌 종목이 옛 기록과 섞인다.
            // 계좌번호를 폴더 이름에 넣어 서로 안 닿게 한다.
            "kis" -> lines += listOf(
                "KIS_APP_KEY=${c.key}",
                "KIS_APP_SECRET=${c.secret}",
                "KIS_ACCOUNT_NO=${c.account}",
                "KIS_ENV=real",
                // 계좌번호별 기록 폴더. 계좌를 바꾸면 자동으로 갈라진다.
                "STATE_SUBDIR=acc_${c.account.ifBlank { "default" }}",
                // ⚠️ 이 값이 없으면 미국 유니버스가 대형주 40종목만으로 좁혀진다
                // (기본값 liquid_subset). 51번 매매법이 노리는 저가 급등주는
                // 그 40종목에 아예 없어서, 신호가 영영 안 뜬다.
                // full 은 6천여 종목을 훑느라 한 바퀴가 훨씬 오래 걸린다.
                "US_UNIVERSE_MODE=full",
            )
            "kiwoom" -> lines += listOf(
                // ⚠️ KIWOOM_ENV 를 빠뜨리면 기본값이 demo(모의투자)가 된다.
                // 그러면 APP_KEY 가 아니라 APP_KEY_MOCK 을 찾기 때문에 키를 못 읽고,
                // 잔고도 종목 목록도 전부 빈 값이 된다(실제로 겪었다).
                "KIWOOM_ENV=real",
                "APP_KEY=${c.key}",
                "APP_SECRET=${c.secret}",
                "KIWOOM_ACCOUNT_NO=${c.account}",
                // 계좌번호별 기록 폴더. 계좌를 바꾸면 자동으로 갈라진다.
                "STATE_SUBDIR=acc_${c.account.ifBlank { "default" }}",
            )
            "upbit" -> lines += listOf(
                "UPBIT_ACCESS_KEY=${c.key}",
                "UPBIT_SECRET_KEY=${c.secret}",
            )
        }
        File(dir, ".env").writeText(lines.joinToString("\n") + "\n")
    }
}

/**
 * assets 에 담긴 엔진 소스(zip)를 앱 폴더로 푼다.
 *
 * 엔진마다 zip 하나로 묶어 둔 이유:
 *  · 파이썬 파일이 80개가 넘어 GitHub 웹 업로드 한도(100개)에 걸린다
 *  · 파일 수만큼 나던 I/O가 없어져 첫 실행이 빠르다
 *
 * ⚠️ 엔진별로 자기 폴더만 건드린다. 서비스들이 각자 다른 프로세스에서 이걸
 * 불러도 서로 같은 폴더를 만지지 않으므로 충돌하지 않는다.
 */
object Assets {

    /**
     * 엔진 코드를 앱 폴더에 푼다. **앱을 켤 때마다 무조건 다시 푼다.**
     *
     * ⚠️ 예전에는 "버전이 같으면 건너뛰기"로 아꼈는데, 그 판단이 어긋나면
     * 폰에 옛 코드가 남아 고친 내용이 반영되지 않는다. 실제로 여러 번 겪었다
     * (새 APK를 깔았는데 화면에 새 버튼이 없거나, 있다가 사라지는 등).
     * 게다가 푸는 도중 프로세스가 죽으면 반쯤 풀린 상태로 굳어버렸다.
     *
     * 코드는 124KB뿐이라 다시 푸는 데 수십 밀리초면 된다. 아껴서 얻는 것보다
     * 어긋났을 때 잃는 게 훨씬 크다. 항상 새로 푸는 쪽이 맞다.
     */
    fun unpackIfNeeded(ctx: Context, root: File, engineId: String) {
        val dir = File(root, engineId)
        root.mkdirs()
        dir.mkdirs()

        // 주 프로세스와 엔진 프로세스가 둘 다 이 함수를 부른다. 잠그지 않으면
        // 한쪽이 푸는 도중 다른 쪽이 같은 파일을 건드려 깨진다.
        val lockFile = File(dir, ".unpack.lock")
        RandomAccessFile(lockFile, "rw").use { raf ->
            raf.channel.lock().use {
                // state/ 와 logs/ 는 절대 건드리지 않는다 (거래 기록·로그)
                dir.listFiles()?.forEach { f ->
                    if (f.name !in KEEP) f.deleteRecursively()
                }
                ctx.assets.open("engines/$engineId.zip").use { unzip(it, dir) }

                val info = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
                val version = "${info.versionName}@${info.lastUpdateTime}"
                android.util.Log.w("Assets", "엔진 코드 갱신: $engineId ($version)")
                File(dir, "state").mkdirs()
                File(dir, "state/.engine_version").writeText(version)
            }
        }
    }

    /** 엔진 코드를 갈아끼울 때도 남겨야 하는 것 — 거래 기록과 로그 */
    private val KEEP = setOf("state", "logs", ".env", ".unpack.lock", ".version")

    private fun unzip(input: java.io.InputStream, outDir: File) {
        outDir.mkdirs()
        val rootPath = outDir.canonicalPath
        java.util.zip.ZipInputStream(input.buffered()).use { zin ->
            while (true) {
                val entry = zin.nextEntry ?: break
                val target = File(outDir, entry.name)
                // ⚠️ zip 안의 이름이 "../.." 로 시작하면 앱 폴더 밖에 파일을 쓸 수
                // 있다(zip slip). 최종 경로가 안쪽인지 반드시 확인한다.
                if (!target.canonicalPath.startsWith(rootPath + File.separator)) {
                    throw SecurityException("잘못된 경로가 들어있습니다: ${entry.name}")
                }
                if (entry.isDirectory) {
                    target.mkdirs()
                } else {
                    target.parentFile?.mkdirs()
                    target.outputStream().use { zin.copyTo(it) }
                }
                zin.closeEntry()
            }
        }
        // zip 에는 빈 폴더가 안 담기므로 여기서 만들어 둔다
        File(outDir, "state").mkdirs()
        File(outDir, "logs").mkdirs()
    }
}
