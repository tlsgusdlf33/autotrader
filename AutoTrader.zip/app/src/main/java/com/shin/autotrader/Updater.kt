package com.shin.autotrader

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/**
 * 폰이 스스로 새 버전을 받아오게 한다.
 *
 * ## 왜 두 갈래인가
 *
 * 이 앱은 껍데기(코틀린)와 매매 엔진(파이썬)이 분리되어 있다. 엔진 코드는
 * assets 의 zip 을 앱 폴더에 풀어서 돌린다(Assets.unpackIfNeeded).
 * 그래서 **엔진만 바꾸는 개선은 APK 를 다시 깔지 않아도 반영할 수 있다.**
 *
 *   · 엔진(매매 로직) — 새 zip 을 받아 앱 폴더에 두면 끝. 설치 없음, 손댈 것 없음.
 *   · APK(화면·서비스) — 안드로이드가 설치를 확인받게 되어 있어 탭 한 번이 필요하다.
 *
 * ⚠️ **완전 무인 설치는 안드로이드가 막아둔 일이다.** 스토어를 거치지 않은 앱은
 * 설치할 때마다 시스템 확인 창이 뜬다(기기 관리자 앱이나 루팅이 아니면 예외 없다).
 * 그래서 APK 는 '미리 받아두고 알림으로 알려주기'까지만 자동으로 한다.
 * 매매 로직 개선은 대부분 엔진 쪽이라, 실제로는 대부분 손댈 일 없이 반영된다.
 *
 * ## 어디서 받아오는가
 *
 * GitHub 릴리스의 고정 주소 하나만 본다.
 *
 *   https://github.com/<계정>/<저장소>/releases/latest/download/update.json
 *
 * ⚠️ GitHub API(api.github.com)를 쓰지 않는다. API 는 인증 없이 시간당 60번
 * 제한이 있고 응답 형식도 바뀔 수 있다. 위 주소는 '가장 새 릴리스의 그 파일'로
 * 영구 리다이렉트되는 고정 주소라, 파일만 받으면 되고 한도도 없다.
 *
 * ⚠️ 받은 파일은 반드시 SHA-256 을 확인한 뒤에 쓴다. 중간에 끊긴 반쪽짜리
 * zip 을 그대로 풀면 엔진이 import 에서 죽고, 원인을 찾기 어렵다.
 */
object Updater {

    private const val TAG = "Updater"
    private const val PREFS = "autotrader_update"
    private const val KEY_AUTO = "auto"
    private const val KEY_BUNDLE = "engine_bundle"
    private const val KEY_LAST_CHECK = "last_check"
    private const val KEY_APK_READY = "apk_ready_code"

    /** 확인 주기. 너무 자주 보면 데이터만 쓰고 얻는 게 없다. */
    private const val CHECK_INTERVAL_MS = 6 * 60 * 60 * 1000L

    private const val CHANNEL = "update"
    private const val NOTIFY_ID = 4242

    /** 다운로드한 엔진 zip 을 두는 곳 */
    private fun updateDir(ctx: Context) = File(ctx.filesDir, "engine_updates")

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    // ──────────────────────────────────────────────────────────
    // 설정
    // ──────────────────────────────────────────────────────────

    /** 자동 업데이트가 켜져 있는가 (기본 켬) */
    fun isAuto(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_AUTO, true)

    fun setAuto(ctx: Context, on: Boolean) {
        prefs(ctx).edit().putBoolean(KEY_AUTO, on).apply()
    }

    /**
     * 지금 폰에 있는 엔진 코드의 번들 번호.
     *
     * ⚠️ 받아둔 게 없으면 APK 의 versionCode 를 쓴다. 빌드할 때 두 값을 같게
     * 맞춰두기 때문에(워크플로의 engines.bundle_id = versionCode), APK 를 새로
     * 깔면 받아둔 옛 번들이 자동으로 무시된다.
     */
    fun engineBundle(ctx: Context): Long {
        val downloaded = prefs(ctx).getLong(KEY_BUNDLE, 0L)
        return maxOf(downloaded, appVersionCode(ctx))
    }

    fun appVersionCode(ctx: Context): Long = runCatching {
        val info = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) info.longVersionCode
        else @Suppress("DEPRECATION") info.versionCode.toLong()
    }.getOrDefault(0L)

    /**
     * 이 엔진에 쓸 zip 파일. 받아둔 새 번들이 있으면 그것, 없으면 null
     * (null 이면 호출하는 쪽이 앱에 내장된 assets 를 쓴다).
     */
    fun downloadedEngineZip(ctx: Context, engineId: String): File? {
        if (prefs(ctx).getLong(KEY_BUNDLE, 0L) <= appVersionCode(ctx)) return null
        val f = File(updateDir(ctx), "$engineId.zip")
        return if (f.isFile && f.length() > 0) f else null
    }

    /** 내려받아 둔 APK (설치 대기 중). 없으면 null */
    fun pendingApk(ctx: Context): File? {
        val code = prefs(ctx).getLong(KEY_APK_READY, 0L)
        if (code <= appVersionCode(ctx)) return null
        val f = File(updateDir(ctx), "app.apk")
        return if (f.isFile && f.length() > 0) f else null
    }

    // ──────────────────────────────────────────────────────────
    // 확인 / 받기
    // ──────────────────────────────────────────────────────────

    /**
     * 배경에서 확인하고, 있으면 받아둔다. 화면을 막지 않는다.
     *
     * @param force true 면 주기를 무시하고 지금 확인한다 (사용자가 직접 눌렀을 때)
     */
    fun checkAsync(ctx: Context, force: Boolean = false, then: ((Result) -> Unit)? = null) {
        val app = ctx.applicationContext
        Thread({ then?.invoke(checkNow(app, force)) }, "updater")
            .apply { isDaemon = true }.start()
    }

    /** 확인 결과 — 화면에 보여줄 것만 담는다. */
    data class Result(
        val checked: Boolean = false,
        val engineUpdated: Boolean = false,
        val apkReady: Boolean = false,
        val latestVersion: String = "",
        val error: String = "",
    )

    /**
     * 지금 자리에서 확인한다 (호출한 스레드에서 돈다 — 반드시 배경 스레드에서).
     *
     * ⚠️ 주 스레드에서 부르면 네트워크 때문에 앱이 멈춘다. 화면 쪽에서는
     * withContext(Dispatchers.IO) 안에서 부르거나 checkAsync 를 쓴다.
     */
    fun checkNow(ctx: Context, force: Boolean = false): Result =
        runCatching { check(ctx.applicationContext, force) }
            .onFailure { Log.w(TAG, "업데이트 확인 실패", it) }
            .getOrDefault(Result(error = "확인 실패"))

    private fun check(ctx: Context, force: Boolean): Result {
        if (!force && !isAuto(ctx)) return Result(error = "자동 업데이트가 꺼져 있습니다")
        val now = System.currentTimeMillis()
        val last = prefs(ctx).getLong(KEY_LAST_CHECK, 0L)
        if (!force && now - last < CHECK_INTERVAL_MS) return Result()

        val base = baseUrl(ctx)
        val manifest = JSONObject(fetchText("$base/update.json"))
        prefs(ctx).edit().putLong(KEY_LAST_CHECK, now).apply()

        val versionName = manifest.optString("version_name")
        val versionCode = manifest.optLong("version_code")
        var engineUpdated = false
        var apkReady = false

        // ── 1) 엔진 코드 (설치 없이 반영된다) ─────────────────────
        // ⚠️ 번들 번호만 보고 받으면, 문서만 고친 빌드에도 엔진을 다시 받고
        // **엔진 프로세스를 재시작한다.** 장중이면 그 사이 손절 감시가 끊긴다.
        // 그래서 파일별 SHA-256 을 지금 쓰고 있는 zip 과 대조해서, 실제로
        // 내용이 다른 것만 받는다. 전부 같으면 아무것도 하지 않는다
        // (번들 번호도 올리지 않는다 — 올리면 그것만으로 재시작이 걸린다).
        val engines = manifest.optJSONObject("engines")
        val bundleId = engines?.optLong("bundle_id") ?: 0L
        if (engines != null && bundleId > engineBundle(ctx) && engineFilesDiffer(ctx, engines)) {
            engineUpdated = downloadEngines(ctx, base, engines, bundleId)
        }

        // ── 2) APK (받아만 두고 알림으로 알린다) ─────────────────
        val apk = manifest.optJSONObject("apk")
        if (apk != null && versionCode > appVersionCode(ctx)) {
            apkReady = downloadApk(ctx, base, apk, versionCode)
        }

        if (engineUpdated || apkReady) {
            notifyUser(ctx, engineUpdated, apkReady, versionName)
        }
        return Result(checked = true, engineUpdated = engineUpdated,
                      apkReady = apkReady, latestVersion = versionName)
    }

    /**
     * 릴리스의 엔진 zip 중 지금 쓰고 있는 것과 **내용이 다른 게 하나라도** 있는가.
     *
     * 지금 쓰는 zip = 받아둔 것이 있으면 그것, 없으면 APK 에 내장된 assets.
     * 실제 파일을 해시해서 비교하므로 별도 기록을 맞춰둘 필요가 없다.
     */
    private fun engineFilesDiffer(ctx: Context, engines: JSONObject): Boolean {
        val files = engines.optJSONObject("files") ?: return false
        for (id in Brokers.ALL.map { it.id }) {
            val want = files.optJSONObject(id)?.optString("sha256").orEmpty()
            if (want.isBlank()) continue
            val have = currentEngineSha(ctx, id) ?: return true   // 못 읽으면 받는 쪽이 안전
            if (!want.equals(have, ignoreCase = true)) {
                Log.w(TAG, "$id 엔진 코드가 바뀌었습니다 — 새로 받습니다")
                return true
            }
        }
        Log.i(TAG, "엔진 코드는 그대로입니다 — 받지 않고 재시작도 하지 않습니다")
        return false
    }

    /** 지금 실제로 쓰고 있는 엔진 zip 의 SHA-256 */
    private fun currentEngineSha(ctx: Context, engineId: String): String? = runCatching {
        val downloaded = downloadedEngineZip(ctx, engineId)
        if (downloaded != null) return@runCatching sha256(downloaded)
        val md = MessageDigest.getInstance("SHA-256")
        ctx.assets.open("engines/$engineId.zip").use { ins ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val n = ins.read(buf)
                if (n <= 0) break
                md.update(buf, 0, n)
            }
        }
        md.digest().joinToString("") { "%02x".format(it) }
    }.getOrNull()

    /**
     * 엔진 zip 세 개를 받아 확인하고 자리에 둔다.
     *
     * ⚠️ 하나라도 실패하면 번들 번호를 올리지 않는다. 세 엔진의 코드 버전이
     * 섞이면 어느 조합으로 돌고 있는지 알 수 없게 된다.
     */
    private fun downloadEngines(ctx: Context, base: String,
                                 engines: JSONObject, bundleId: Long): Boolean {
        val files = engines.optJSONObject("files") ?: return false
        val dir = updateDir(ctx).apply { mkdirs() }
        val staged = mutableListOf<Pair<File, File>>()   // (임시, 최종)
        for (id in Brokers.ALL.map { it.id }) {
            val entry = files.optJSONObject(id) ?: continue
            val name = entry.optString("name").ifBlank { "$id.zip" }
            val want = entry.optString("sha256")
            val tmp = File(dir, "$id.zip.part")
            runCatching { download("$base/$name", tmp) }.onFailure {
                Log.w(TAG, "$id 엔진 내려받기 실패", it)
                tmp.delete()
                return false
            }
            val got = sha256(tmp)
            if (want.isNotBlank() && !want.equals(got, ignoreCase = true)) {
                Log.e(TAG, "$id 엔진 파일이 손상되었습니다 (기대 $want, 실제 $got)")
                tmp.delete()
                return false
            }
            staged += tmp to File(dir, "$id.zip")
        }
        if (staged.isEmpty()) return false
        // 전부 받아서 확인까지 끝난 뒤에 한꺼번에 자리를 바꾼다
        staged.forEach { (tmp, dest) ->
            dest.delete()
            if (!tmp.renameTo(dest)) {
                tmp.copyTo(dest, overwrite = true); tmp.delete()
            }
        }
        prefs(ctx).edit().putLong(KEY_BUNDLE, bundleId).apply()
        Log.w(TAG, "엔진 코드를 새로 받았습니다 (번들 $bundleId) — 엔진을 다시 시작하면 반영됩니다")
        return true
    }

    private fun downloadApk(ctx: Context, base: String, apk: JSONObject, versionCode: Long): Boolean {
        val name = apk.optString("name").ifBlank { "app-debug.apk" }
        val want = apk.optString("sha256")
        val dir = updateDir(ctx).apply { mkdirs() }
        val tmp = File(dir, "app.apk.part")
        runCatching { download("$base/$name", tmp) }.onFailure {
            Log.w(TAG, "APK 내려받기 실패", it); tmp.delete(); return false
        }
        val got = sha256(tmp)
        if (want.isNotBlank() && !want.equals(got, ignoreCase = true)) {
            Log.e(TAG, "APK 가 손상되었습니다 (기대 $want, 실제 $got)")
            tmp.delete(); return false
        }
        val dest = File(dir, "app.apk")
        dest.delete()
        if (!tmp.renameTo(dest)) { tmp.copyTo(dest, overwrite = true); tmp.delete() }
        prefs(ctx).edit().putLong(KEY_APK_READY, versionCode).apply()
        Log.w(TAG, "새 APK 를 받아뒀습니다 (버전 $versionCode) — 설치만 눌러주면 됩니다")
        return true
    }

    // ──────────────────────────────────────────────────────────
    // 설치 (사용자 확인이 반드시 필요한 부분)
    // ──────────────────────────────────────────────────────────

    /**
     * 받아둔 APK 설치 화면을 띄운다.
     *
     * ⚠️ FileProvider 로 넘겨야 한다. 안드로이드 7부터 file:// URI 를 다른 앱
     * (설치 관리자)에 넘기면 FileUriExposedException 으로 죽는다.
     */
    fun installPendingApk(ctx: Context): Boolean {
        val apk = pendingApk(ctx) ?: return false
        return runCatching {
            val uri: Uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.updates", apk)
            ctx.startActivity(Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
            true
        }.onFailure { Log.w(TAG, "설치 화면을 띄우지 못했습니다", it) }.getOrDefault(false)
    }

    // ──────────────────────────────────────────────────────────
    // 알림
    // ──────────────────────────────────────────────────────────

    private fun notifyUser(ctx: Context, engineUpdated: Boolean, apkReady: Boolean,
                           versionName: String) = runCatching {
        val mgr = ctx.getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            mgr.createNotificationChannel(
                NotificationChannel(CHANNEL, "업데이트", NotificationManager.IMPORTANCE_DEFAULT))
        }
        val title = if (apkReady) "새 버전 $versionName 준비됨" else "매매 로직이 새로 반영되었습니다"
        val body = when {
            apkReady && engineUpdated ->
                "매매 로직은 이미 반영됐습니다. 화면까지 새로 하려면 눌러서 설치해주세요."
            apkReady -> "눌러서 설치하면 새 화면이 적용됩니다. 설정과 거래 기록은 그대로입니다."
            else -> "$versionName 의 매매 로직을 받았습니다. 엔진을 다시 시작할 때 적용됩니다."
        }
        val tap = PendingIntent.getActivity(
            ctx, 77,
            Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE)
        mgr.notify(NOTIFY_ID, NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setAutoCancel(true)
            .setContentIntent(tap)
            .build())
    }.getOrNull()

    // ──────────────────────────────────────────────────────────
    // 잡일
    // ──────────────────────────────────────────────────────────

    /** 릴리스 파일들이 있는 고정 주소 */
    private fun baseUrl(ctx: Context): String {
        val repo = ctx.getString(R.string.update_repo).trim().trim('/')
        return "https://github.com/$repo/releases/latest/download"
    }

    private fun open(url: String): HttpURLConnection =
        (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000
            readTimeout = 30_000
            // ⚠️ 이 주소는 실제 파일이 있는 곳으로 리다이렉트된다. 따라가지 않으면
            // 본문이 아니라 302 응답만 받는다.
            instanceFollowRedirects = true
            setRequestProperty("Accept", "*/*")
        }

    private fun fetchText(url: String): String {
        val c = open(url)
        try {
            if (c.responseCode !in 200..299) error("HTTP ${c.responseCode} — $url")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun download(url: String, target: File) {
        val c = open(url)
        try {
            if (c.responseCode !in 200..299) error("HTTP ${c.responseCode} — $url")
            target.parentFile?.mkdirs()
            target.outputStream().use { out -> c.inputStream.use { it.copyTo(out) } }
        } finally {
            c.disconnect()
        }
    }

    private fun sha256(f: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        f.inputStream().use { ins ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val n = ins.read(buf)
                if (n <= 0) break
                md.update(buf, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }
}
