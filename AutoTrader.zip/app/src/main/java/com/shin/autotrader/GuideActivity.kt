package com.shin.autotrader

import android.os.Bundle
import android.view.View
import androidx.appcompat.widget.AppCompatButton
import androidx.appcompat.app.AppCompatActivity
import com.shin.autotrader.databinding.ActivityGuideBinding

/**
 * API 키 발급 안내.
 *
 * 증권사 홈페이지를 링크로만 던지면 사용자가 어느 메뉴로 들어가야 하는지
 * 모른다. 그래서 실제 클릭 경로를 단계로 적었다.
 *
 * ⚠️ 증권사가 화면을 개편하면 이 안내와 실제가 달라진다. 그래서 각 안내 끝에
 * "메뉴 이름이 다르면 검색창에 'Open API'로 찾으세요"를 붙여 둔다.
 */
class GuideActivity : AppCompatActivity() {

    private lateinit var b: ActivityGuideBinding
    private val buttons = mutableListOf<AppCompatButton>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityGuideBinding.inflate(layoutInflater)
        setContentView(b.root)

        Brokers.ALL.forEachIndexed { i, broker ->
            // ⚠️ 그냥 Button을 쓰면 Material3 테마가 이걸 MaterialButton으로 바꿔치기하고,
            // 내가 지정한 배경 대신 colorPrimary(주황)로 칠해버린다. 그러면 주황 배경에
            // 주황 글씨가 되어 아무것도 안 보인다. AppCompatButton은 지정한 배경을 그대로 쓴다.
            val btn = AppCompatButton(this).apply {
                text = broker.label
                isAllCaps = false
                textSize = 13f
                setBackgroundResource(R.drawable.bg_pill)
                layoutParams = android.widget.LinearLayout.LayoutParams(
                    0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1f,
                ).also { if (i > 0) it.marginStart = 8 }
                setOnClickListener { show(i) }
            }
            buttons += btn
            b.tabs.addView(btn)
        }
        b.btnBack.setOnClickListener { finish() }
        show(0)
    }

    private fun show(index: Int) {
        buttons.forEachIndexed { i, btn ->
            btn.setBackgroundResource(if (i == index) R.drawable.bg_pill_on else R.drawable.bg_pill)
            btn.setTextColor(
                androidx.core.content.ContextCompat.getColor(
                    this, if (i == index) R.color.accent else R.color.muted,
                ),
            )
        }
        b.guideText.text = GUIDES[index]
        b.guideText.visibility = View.VISIBLE
    }

    companion object {
        private val KIS = """
            한국투자증권 Open API 키 발급받기

            ■ 준비물
            · 한국투자증권 계좌 (비대면 개설 가능)
            · 공동인증서 또는 간편인증

            ■ 1단계 · 계좌 만들기
            이미 계좌가 있으면 넘어가세요.
            한국투자증권 앱에서 비대면으로 개설할 수 있고, 보통 하루 안에 끝납니다.

            ■ 2단계 · KIS Developers 신청
            1. 한국투자증권 홈페이지 접속
            2. 상단 메뉴에서 [서비스신청] → [Open API] → [KIS Developers]
            3. [KIS Developers 서비스 신청하기] 클릭
            4. 인증서 로그인 → 휴대폰 인증
            5. 사용할 계좌를 선택하고 신청 완료

            ■ 3단계 · 키 확인
            신청이 끝나면 두 가지 값이 나옵니다.
            · APP KEY      (36자 정도의 문자열)
            · APP SECRET   (180자 정도의 아주 긴 문자열)

            APP SECRET은 다시 볼 수 없는 경우가 있으니 나올 때 바로
            복사해 두세요.

            ■ 4단계 · 앞 화면에 입력
            · APP KEY      → APP KEY 칸
            · APP SECRET   → APP SECRET 칸
            · 계좌번호 앞 8자리 → 계좌번호 칸
              (12345678-01 이라면 12345678만 넣습니다)

            ■ 참고
            · API 사용료는 없습니다. 매매 수수료만 평소와 같이 붙습니다.
            · 3개월 이상 거래가 없으면 서비스가 자동 해지될 수 있습니다.
            · 메뉴 이름이 다르면 홈페이지 검색창에 'Open API'로 찾으세요.
        """.trimIndent()

        private val KIWOOM = """
            키움증권 Open API 키 발급받기

            ■ 준비물
            · 키움증권 계좌
            · 공동인증서 또는 간편인증

            ■ 1단계 · 계좌 만들기
            키움증권 앱(영웅문S#)에서 비대면 개설이 가능합니다.

            ■ 2단계 · REST API 신청
            1. 키움증권 홈페이지 접속
            2. [고객서비스] 또는 [트레이딩] 메뉴에서 'Open API' 찾기
            3. REST API(또는 오픈API) 사용 신청
            4. 인증서 로그인 후 약관 동의
            5. 사용할 계좌 선택

            ■ 3단계 · 키 확인
            신청 후 아래 두 값을 받습니다.
            · 앱 키    (App Key)
            · 앱 시크릿 (App Secret)

            ■ 4단계 · 앞 화면에 입력
            · 앱 키     → 앱 키 칸
            · 앱 시크릿 → 앱 시크릿 칸
            · 계좌번호 앞 8자리 → 계좌번호 칸

            ■ 참고
            · 예전 방식(OCX/키움 OpenAPI+)은 윈도우 전용이라 이 앱에서는
              쓸 수 없습니다. 반드시 REST API 쪽으로 신청하세요.
            · 메뉴 이름이 다르면 홈페이지 검색창에 'Open API'로 찾으세요.
        """.trimIndent()

        private val UPBIT = """
            업비트 Open API 키 발급받기

            ■ 준비물
            · 업비트 계정 + 케이뱅크 연결 (원화 거래에 필요)
            · 2단계 인증(OTP) 설정

            ■ 1단계 · Open API 관리 들어가기
            1. 업비트 홈페이지(PC 권장) 로그인
            2. 우측 상단 [고객센터] 옆 계정 메뉴 → [Open API 관리]
               또는 주소창에 upbit.com/mypage/open_api_management

            ■ 2단계 · 권한 고르기
            자동매매에는 아래 세 가지가 필요합니다.
            · 자산 조회
            · 주문 조회
            · 주문하기

            ⚠️ [출금하기]는 절대 체크하지 마세요.
            이 앱은 출금 기능을 쓰지 않습니다. 켜두면 키가 유출됐을 때
            자산이 그대로 빠져나갈 수 있습니다.

            ■ 3단계 · IP 등록
            업비트는 허용할 IP를 등록해야 합니다.
            · 집·회사 와이파이에서만 쓴다면 그 IP를 넣으세요.
            · LTE/5G로 이동하며 쓰면 IP가 계속 바뀝니다. 이 경우
              사용하는 통신망의 IP를 그때그때 추가해야 합니다.

            IP가 안 맞으면 조회는 되는데 주문만 실패합니다.
            이 앱에서 매수가 계속 안 되면 먼저 IP 등록을 확인하세요.

            ■ 4단계 · 키 확인
            · Access Key
            · Secret Key   ← 이 화면을 벗어나면 다시 볼 수 없습니다

            Secret Key는 나온 자리에서 바로 복사해 두세요.
            잃어버리면 키를 새로 발급받아야 합니다.

            ■ 5단계 · 앞 화면에 입력
            · Access Key → Access Key 칸
            · Secret Key → Secret Key 칸
            · 업비트는 계좌번호가 없어 입력란이 나오지 않습니다.

            ■ 참고
            · 키 유효기간은 1년입니다. 만료되면 다시 발급받아야 합니다.
        """.trimIndent()

        val GUIDES = listOf(KIS, KIWOOM, UPBIT)
    }
}
