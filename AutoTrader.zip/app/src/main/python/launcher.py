"""
엔진 하나를 이 프로세스에서 띄운다.

⚠️ 이 파일은 '한 프로세스에 엔진 하나'를 전제로 한다.
   예전에는 세 엔진을 한 프로세스 안에서 스레드로 돌렸는데, 실제로 깨졌다:

     · os.chdir 은 프로세스 전체에 하나뿐이다. A엔진이 자기 화면 폴더를
       잡는 사이 B엔진이 폴더를 바꾸면, A의 포트에 B의 화면이 붙는다.
     · sys.path / sys.modules 도 프로세스 공용이다. 세 프로젝트가 config,
       engine, web 이라는 같은 이름을 쓰기 때문에, 함수 안에서 뒤늦게
       import하는 코드가 남의 모듈을 집어온다.

   그래서 안드로이드 쪽에서 엔진마다 별도 프로세스(:kis, :kiwoom, :upbit)로
   띄우고, 여기서는 딱 하나만 실행한다. 그러면 위 문제가 원천적으로 없어진다.
"""
from __future__ import annotations

import logging
import os
import sys
import threading
import traceback

logger = logging.getLogger("launcher")

_state = {"status": "idle", "error": ""}


def _setup_logging(app_dir: str) -> None:
    """엔진 로그를 파일로 남긴다.

    ⚠️ 원래는 main.py 가 로깅을 설정했는데, 앱에서는 main.py 를 거치지 않고
    여기서 바로 띄우기 때문에 로그가 아무 데도 안 남았다. 그래서 엔진이 왜
    안 뜨는지 확인할 방법이 없었다. 앱 화면이 이 파일을 읽어서 보여준다.
    """
    log_dir = os.path.join(app_dir, "logs")
    os.makedirs(log_dir, exist_ok=True)
    root = logging.getLogger()
    if any(isinstance(h, logging.FileHandler) for h in root.handlers):
        return
    handler = logging.FileHandler(os.path.join(log_dir, "engine.log"), encoding="utf-8")
    handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s"))
    root.addHandler(handler)
    root.setLevel(logging.INFO)


def status() -> str:
    return _state["status"]


def error() -> str:
    return _state["error"]


def start(app_dir: str, port: int) -> str:
    """엔진 하나를 띄운다. 대시보드 서버가 계속 돌기 때문에 이 함수는 돌아오지 않는다.

    안드로이드 쪽에서 별도 스레드로 호출한다.
    """
    try:
        if not os.path.isdir(app_dir):
            raise FileNotFoundError(f"엔진 폴더가 없습니다: {app_dir}")

        os.chdir(app_dir)
        if app_dir not in sys.path:
            sys.path.insert(0, app_dir)

        _setup_logging(app_dir)
        logger.info("=== 엔진 기동 시작 (포트 %s) ===", port)

        _state["status"] = "importing"
        logger.info("설정과 매매 엔진을 불러오는 중... (처음엔 pandas 준비 때문에 오래 걸립니다)")
        import config  # noqa: F401  (.env를 읽어 설정을 만든다)
        logger.info("설정 읽기 완료")

        # ⚠️ 지금 어느 계좌에 붙었는지 로그에 남긴다.
        # 계좌를 바꿨는데 엔진이 옛 설정을 들고 있으면 화면에는 옛 계좌 종목이
        # 그대로 뜬다. 겉으로는 구분이 안 돼서, 여기 찍힌 계좌번호로 확인한다.
        try:
            acct = (getattr(config.settings, "account_no", "")
                    or getattr(config.settings, "kis_account_no", "") or "")
            sub = os.getenv("STATE_SUBDIR", "(공용)")
            if acct:
                logger.info("접속 계좌: %s  /  기록 폴더: %s", acct, sub)
        except Exception:
            pass

        # ⚠️ 설정이 잘못돼도 엔진은 그냥 뜬다. 그리고 조회 결과가 전부 비어서
        #    "계좌엔 종목이 있는데 화면은 텅 빈" 상태가 된다(키움 KIWOOM_ENV 누락으로
        #    실제로 겪었다). 그래서 기동 직후 스스로 점검해 로그에 남긴다.
        try:
            problems = config.settings.validate()
        except Exception:
            problems = []
        if problems:
            for msg in problems:
                logger.error("⚠️ 설정 문제: %s", msg)
            _state["error"] = problems[0]
        else:
            logger.info("설정 점검 통과")
        from engine.engine import engine as trading_engine
        logger.info("매매 엔진 준비 완료")
        # ⚠️ 여기서 증권사 접속(토큰 발급)이 일어날 수 있어 시간이 걸린다.
        #    키가 틀렸거나 통신이 막히면 이 줄에서 오래 멈춘다.
        from web import server as web_server
        logger.info("대시보드 준비 완료")

        # 매매 판단 루프는 별도 스레드에서, 대시보드는 이 스레드에서 돈다.
        _state["status"] = "starting"
        threading.Thread(target=trading_engine.run_forever, daemon=True,
                         name="engine-loop").start()

        _state["status"] = "running"
        logger.info("엔진 기동: %s (포트 %s)", app_dir, port)
        _state["server_module"] = web_server
        web_server.run_server(port)
        return "stopped"
    except Exception as e:
        _state["status"] = "error"
        _state["error"] = f"{type(e).__name__}: {e}"
        logger.error("엔진 기동 실패(%s):\n%s", app_dir, traceback.format_exc())
        return f"error: {e}"



def take_events() -> str:
    """앱이 알림으로 띄울 사건을 가져온다 (가져간 것은 다시 안 나온다).

    엔진은 별도 프로세스라 안드로이드 알림을 직접 띄울 수 없다. 그래서 매도·
    손절실패 같은 일을 DB에 적어두고, 앱이 주기적으로 이걸 읽어 알림으로 띄운다.
    반환 형식: [{"level","title","body"}, ...] 을 JSON 문자열로.
    """
    try:
        import json as _json
        from engine import state
        rows = state.take_unseen_events()
        return _json.dumps([{"level": r.get("level", "info"),
                             "title": r.get("title", ""),
                             "body": r.get("body", "")} for r in rows], ensure_ascii=False)
    except Exception:
        return "[]"


def stop_server() -> None:
    """대시보드 포트를 즉시 닫는다.

    ⚠️ 프로세스를 끝내기 직전에 부른다. 포트를 붙든 채로 죽으면 새 프로세스가
    같은 포트를 못 잡아 기동에 실패한다("Address already in use").
    그러면 화면에는 옛 프로세스가 계속 응답해서, 설정을 바꿔도 반영이 안 된
    것처럼 보인다.
    """
    try:
        from web import microapi
        microapi.shutdown()
        logger.info("대시보드 포트를 닫았습니다")
    except Exception:
        logger.warning("포트 닫기 실패:\n%s", traceback.format_exc())


def stop() -> None:
    """매매를 멈춘다.

    ⚠️ 파이썬 스레드는 밖에서 강제로 죽일 수 없다. 대신 DB의 '중지' 플래그를
    세워서 엔진이 스스로 매매를 그만두게 한다. 프로세스가 끝나면 데몬 스레드라
    함께 사라진다.
    """
    try:
        from engine import state
        state.set_enabled(False)
        _state["status"] = "stopped"
    except Exception:
        logger.warning("정지 요청 실패:\n%s", traceback.format_exc())
